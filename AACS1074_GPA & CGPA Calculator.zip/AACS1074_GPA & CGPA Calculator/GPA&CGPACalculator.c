#include <stdio.h>
#include <string.h>
#pragma warning (disable : 4996)
#define STAFFNAME "Joe"      //for staff login before generate gpa and cgpa
#define STAFFPASS "Joema123"   //for staff login before generate gpa and cgpa

void stafflogin();        //Function for Staff Admin Login
void gpaCal();            //Function for GPA Calculator
void cgpaCal();           //Function for CGPA Calculator
void viewgpa();           //Function for GPA Viewer for Staff Admin
void viewcgpa();          //Function for CGPA Viewer for Staff Admin
void viewgpaStudent();    //Function for CGPA Viewer for Student
void viewcgpaStudent();   //Function for CGPA Viewer for Student

void main() {   //Main Function to run the program

	int role, selectS, selects;

	//Home page
	printf("  __________________________________________________________________________________________        \n");
	printf(" |         ___        ___           ___   ___   __   ___   ___      ___     _               |       \n");
	printf(" |  |   / |   | |    |        |    |   | |   | |    |   | |   |    |       / \\    |      |  |      \n");
	printf(" |  |__/  |   | |    |___     |    |___| |___| |__  |___| |___|    |       \\       \\    /   |     \n");
	printf(" |  |  \\  |   | |    |    |   |    |     |   |    | |   | | \\      |       /\\/      \\  /    |   \n");
	printf(" |  |   \\ |___| |___ |___ |___|    |     |   | ___| |   | |  \\     |___    \\/\\       \\/     |  \n");
	printf(" |__________________________________________________________________________________________|       \n");
	printf("\n");

	//Choices for user to select their role
	puts("Welcome to Kolej Pasar GPA & CGPA Calculator & Viewer.\n");
	printf("1) Staff Admin Page\n");
	printf("2) Student Page\n");
	printf("3) Exit\n\n");
	printf("Where would you like to go? (1, 2, 3) > ");
	scanf("%d", &role);
	printf("\n");

	//Navigation according to which choice user input

	//Staff Page with choices for staff to choose where to go
	switch (role) {
	case 1:
		printf("-------------------------------------------\n");
		puts("To enter Staff Admin Page, please login.\n");
		stafflogin();
		printf("-------------------------------------------\n");
		printf("Hi Joe Ma, Welcome to Staff Admin Page.\n\n");
		printf("1) Generate student's GPA\n");
		printf("2) Generate student's CGPA\n");
		printf("3) View student's GPA\n");
		printf("4) View student's CGPA\n");
		printf("5) Back\n\n");
		printf("Where would you like to go? > ");
		scanf("%d", &selectS);
		rewind(stdin);
		printf("\n");

		switch (selectS) {
		case 1:
			//Staff admin page to Generate student's GPA
			printf("-------------------------------------------\n");
			gpaCal();  //Function Call gpaCal();
			break;
		case 2:
			//Staff admin page to Generate student's CGPA
			printf("-------------------------------------------\n");
			cgpaCal();  //Function Call cgpaCal();
			break;
		case 3:
			//Staff admin page to View student's GPA
			printf("-------------------------------------------\n");
			viewgpa();
			break;
		case 4:
			//Staff admin page to View student's CGPA
			printf("-------------------------------------------\n");
			viewcgpa();
			break;
		default:
			//Navigate back to Menu Page
			printf("-------------------------------------------\n");
			system("CLS");
			main();  //Function Call main()
		}
		break;

	case 2:
		//Student page with choices for student to choose where to go
		printf("-------------------------------------------\n");
		printf("Welcome to Student Page.\n\n");
		printf("1) View student's GPA\n");
		printf("2) View student's CGPA\n");
		printf("3) Back\n\n");
		printf("Where would you like to go? > ");
		scanf("%d", &selects);
		rewind(stdin);
		printf("\n");

		switch (selects) {
		case 1:
			//Student page to View GPA
			printf("-------------------------------------------\n");
			viewgpaStudent();
			break;
		case 2:
			//Student page to View CGPA
			printf("-------------------------------------------\n");
			viewcgpaStudent();
			break;
		default:
			//Navigate back to Menu Page
			printf("-------------------------------------------\n");
			system("CLS");
			main();  //Function Call main()
		}
		break;

		//End Program
	case 3:
		printf("-------------------------------------------\n\n");
		printf("Thanks for using Kolej Pasar GPA & CGPA Calculator & Viewer!\n");
		printf("We awaits your next arrival.\n\n");
		printf("-------------------------------------------\n");
		break;

		//Prevent entry any function or exit program if chosen invalid option
	default:
		puts("Invalid option, please try again later.");
		printf("Input 0 to return. > ");
		scanf("%d", &role);
		system("CLS");
		main();
	}
}

void stafflogin() {  //Function for staff login

	char staffName[30];
	char staffPW[15];
	int nope;

	//Staff must login before entering Staff Admin Page
	printf("Enter Staff Admin Name > ");
	scanf("%s", staffName);

	printf("Enter Staff Admin Password > ");
	scanf("%s", staffPW);

	// Compare if input is the same with defined value
	if (strcmp(staffName, STAFFNAME) == 0 && strcmp(staffPW, STAFFPASS) == 0) {
		printf("\n");
	}
	else {
		//Wrong input , prevent entering Staff Admin Page
		printf("Username or Password is incorrect, please try again later.\n\n");
		printf("Input 0 to return. > ");
		scanf("%d", &nope);
		system("CLS");
		main();
	}
}

void gpaCal() {  //Function for GPA Calculator

	char studName[30];
	char studID[11];
	char courseID[9];
	int cHour, totalcHour = 0, sem, goBack;
	float gradePoint, qualityPoint, totalqualityPoint = 0, gpa;

	//Staff enters student's information
	puts("Generate student's GPA : \n");
	printf("Enter student's name > ");
	gets(studName);
	rewind(stdin);
	printf("Enter Student ID (eg. KPKL12345) > KPKL");
	gets(studID);
	rewind(stdin);
	printf("Enter current Semester (1/2/3) > ");
	scanf("%d", &sem);
	rewind(stdin);
	printf("\n");

	do {   //Staff input student's course information and grades obtained
		printf("Enter Course Code (eg. AACS1074) [None if no more courses] > ");
		gets(courseID);
		rewind(stdin);
		printf("Enter Credit Hour (Last digit of Course Code) [0 if no more courses] > ");
		scanf("%d", &cHour);
		rewind(stdin);
		printf("Enter Grade Point (eg. A = 4.00 / 72%% = 3.00 ) obtained from course %s [0 to stop] > ", courseID);
		scanf("%f", &gradePoint);
		rewind(stdin);
		printf("\n");

		qualityPoint = gradePoint * cHour;
		totalqualityPoint = totalqualityPoint + qualityPoint;
		totalcHour = totalcHour + cHour;
		gpa = totalqualityPoint / totalcHour;

		//System loops the input for course information until user key in 0 to stop the loop
	} while (gradePoint != 0);

	//Output
	printf("-------------------------------------------\n");
	printf("Student Name              : %s\n", studName);
	printf("Student ID                : KPKL%s\n", studID);
	printf("Current Semester          : Semester %d\n", sem);
	printf("Your GPA for Semester %d   : %.2f  \n", sem, gpa);
	printf("-------------------------------------------\n");
	printf("\n");
	//Choices for Staff Admin to choose where to go
	printf("1) Generate CGPA\n");
	printf("2) View GPA\n");
	printf("3) View CGPA\n");
	printf("4) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &goBack);
	rewind(stdin);
	printf("\n");

	switch (goBack) {
	case 1:
		printf("-------------------------------------------\n");
		cgpaCal();  //Function call cgpaCal()
		break;
	case 2:
		printf("-------------------------------------------\n");
		viewgpa();  //Function call viewgpa()
		break;
	case 3:
		printf("-------------------------------------------\n");
		viewcgpa();  //Function call viewcgpa()
		break;
	case 4:
		system("CLS");
		main();    //Function call main()
		break;
	default:
		system("CLS");
		main();    //Function call main()
	}
}

void cgpaCal() { //Function for CGPA Calculator

	char studName[30];
	char studID[11];
	int sem = 1, goBack;
	float gpa, totalgpa = 0, cgpa;

	//Staff enters student's information
	puts("Generate student's CGPA : \n");
	printf("Enter student's name > ");
	gets(studName);
	rewind(stdin);
	printf("Enter Student ID (eg. KPKL12345) > KPKL");
	gets(studID);
	rewind(stdin);
	printf("\n");

	do {    //Staff input student's GPA obtained from each semester
		printf("Enter GPA for Semester %d [0 to stop] > ", sem);
		scanf("%f", &gpa);
		rewind(stdin);
		printf("\n");
		sem++;

		totalgpa = totalgpa + gpa;
		cgpa = totalgpa / (sem - 2);

	} while (gpa != 0);    //System loops the input for student's GPA obtained until user key in 0 to stop the loop

	//Output
	printf("-------------------------------------------\n");
	printf("Student Name     : %s\n", studName);
	printf("Student ID       : KPKL%s\n", studID);
	printf("Your CGPA        : %.2f  \n", cgpa);
	printf("-------------------------------------------\n");
	printf("\n");
	//Choices for Staff Admin to choose where to go
	printf("1) Generate GPA\n");
	printf("2) View GPA\n");
	printf("3) View CGPA\n");
	printf("4) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &goBack);
	rewind(stdin);
	printf("\n");

	switch (goBack) {
	case 1:
		printf("-------------------------------------------\n");
		gpaCal();    //Function call gpaCal()
		break;
	case 2:
		printf("-------------------------------------------\n");
		viewgpa();   //Function call viewgpa()
		break;
	case 3:
		printf("-------------------------------------------\n");
		viewcgpa();  //Function call viewcgpa()
		break;
	case 4:
		system("CLS");
		main();      //Function call main()
		break;
	default:
		system("CLS");
		main();      //Function call main()
	}
}

void viewgpa() {     //Function for viewgpa()

	//Preset student's information
	char studID[4][100] = { "","10123","12345","00123" };
	char studName[4][100] = { "","Bryan Law","James Chow","Tan Ah Gaw" };
	int sem[4] = { 0, 1, 2, 3 };
	float gpa[4] = { 0, 3.75, 3.64, 4.00 };
	int ret;

	puts("View student's GPA : \n");
	printf("Enter student ID (eg. KPKL00123) > KPKL");
	scanf("%s", &studID);

	//Output
	if (strcmp(studID, studID[0]) == 1) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[0]);
		printf("Student ID                : KPKL%s\n", studID[0]);
		printf("Current Semester          : Semester %d\n", sem[0]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[0], gpa[0]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[1]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[1]);
		printf("Student ID                : KPKL%s\n", studID[1]);
		printf("Current Semester          : Semester %d\n", sem[1]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[1], gpa[1]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[2]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[2]);
		printf("Student ID                : KPKL%s\n", studID[2]);
		printf("Current Semester          : Semester %d\n", sem[2]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[2], gpa[2]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[3]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[3]);
		printf("Student ID                : KPKL%s\n", studID[3]);
		printf("Current Semester          : Semester %d\n", sem[3]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[3], gpa[3]);
		printf("-------------------------------------------\n");
	}
	else
		printf("\nStudent ID does not exist.\n");

	//Choices for Staff Admin to choose where to go
	printf("\n");
	printf("1) Generate GPA\n");
	printf("2) Generate CGPA\n");
	printf("3) View GPA\n");
	printf("4) View CGPA\n");
	printf("5) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &ret);
	rewind(stdin);
	printf("\n");

	switch (ret) {
	case 1:
		printf("-------------------------------------------\n");
		gpaCal();  //Function call gpaCal()
		break;
	case 2:
		printf("-------------------------------------------\n");
		cgpaCal();  //Function call cgpaCal()
		break;
	case 3:
		printf("-------------------------------------------\n");
		viewgpa();  //Function call viewgpa()
		break;
	case 4:
		printf("-------------------------------------------\n");
		viewcgpa();  //Function call viewcgpa()
		break;
	case 5:
		system("CLS");
		main();      //Function call main()
		break;
	default:
		system("CLS");
		main();      //Function call main()
	}
}

void viewcgpa() {    //Function for viewgpa()

	//Preset student's information
	char studID[4][100] = { "","10123","12345","00123" };
	char studName[4][100] = { "","Bryan Law","James Chow","Tan Ah Gaw" };
	float cgpa[4] = { 0, 2.95, 3.25, 3.75 };
	int ret;

	puts("View student's CGPA : \n");
	printf("Enter student ID (eg. KPKL10123) > KPKL");
	scanf("%s", &studID);

	//Output
	if (strcmp(studID, studID[0]) == 1) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[0]);
		printf("Student ID        : KPKL%s\n", studID[0]);
		printf("Your CGPA         : %.2f  \n", cgpa[0]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[1]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[1]);
		printf("Student ID        : KPKL%s\n", studID[1]);
		printf("Your CGPA         : %.2f  \n", cgpa[1]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[2]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[2]);
		printf("Student ID        : KPKL%s\n", studID[2]);
		printf("Your CGPA         : %.2f  \n", cgpa[2]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[3]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[3]);
		printf("Student ID        : KPKL%s\n", studID[3]);
		printf("Your CGPA         : %.2f  \n", cgpa[3]);
		printf("-------------------------------------------\n");
	}
	else
		printf("\nStudent ID does not exist.\n");

	//Choices for Staff Admin to choose where to go
	printf("\n");
	printf("1) Generate GPA\n");
	printf("2) Generate CGPA\n");
	printf("3) View GPA\n");
	printf("4) View CGPA\n");
	printf("5) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &ret);
	rewind(stdin);
	printf("\n");

	switch (ret) {
	case 1:
		printf("-------------------------------------------\n");
		gpaCal();  //Function call gpaCal()
		break;
	case 2:
		printf("-------------------------------------------\n");
		cgpaCal();  //Function call cgpaCal()
		break;
	case 3:
		printf("-------------------------------------------\n");
		viewgpa();  //Function call viewgpa()
		break;
	case 4:
		printf("-------------------------------------------\n");
		viewcgpa();  //Function call viewcgpa()
		break;
	case 5:
		system("CLS");
		main();    //Function call main()
		break;
	default:
		system("CLS");
		main();    //Function call main()
	}
}

void viewgpaStudent() {     //Function for viewgpaStudent()

	//Preset student's information
	char studID[4][100] = { "","10123","12345","00123" };
	char studName[4][100] = { "","Bryan Law","James Chow","Tan Ah Gaw" };
	int sem[4] = { 0, 1, 2, 3 };
	float gpa[4] = { 0, 3.75, 3.64, 4.00 };
	int ret;

	puts("View student's GPA : \n");
	printf("Enter student ID (eg. KPKL10123) > KPKL");
	scanf("%s", &studID);

	//Output
	if (strcmp(studID, studID[0]) == 1) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[0]);
		printf("Student ID                : KPKL%s\n", studID[0]);
		printf("Current Semester          : Semester %d\n", sem[0]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[0], gpa[0]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[1]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[1]);
		printf("Student ID                : KPKL%s\n", studID[1]);
		printf("Current Semester          : Semester %d\n", sem[1]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[1], gpa[1]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[2]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[2]);
		printf("Student ID                : KPKL%s\n", studID[2]);
		printf("Current Semester          : Semester %d\n", sem[2]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[2], gpa[2]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[3]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name              : %s\n", studName[3]);
		printf("Student ID                : KPKL%s\n", studID[3]);
		printf("Current Semester          : Semester %d\n", sem[3]);
		printf("Your GPA for Semester %d   : %.2f  \n", sem[3], gpa[3]);
		printf("-------------------------------------------\n");
	}
	else
		printf("\nStudent ID does not exist.\n");

	//Choices for Student to choose where to go
	printf("\n");
	printf("1) View GPA\n");
	printf("2) View CGPA\n");
	printf("3) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &ret);
	rewind(stdin);
	printf("\n");

	switch (ret) {
	case 1:
		printf("-------------------------------------------\n");
		viewgpaStudent();   //Function call viewgpaStudent()
		break;
	case 2:
		printf("-------------------------------------------\n");
		viewcgpaStudent();  //Function call viewcgpaStudent()
		break;
	case 3:
		system("CLS");
		main();    //Function call main()
		break;
	default:
		system("CLS");
		main();    //Function call main()
	}
}

void viewcgpaStudent() {    //Function for viewcgpaStudent()

	//Preset student's information
	char studID[4][100] = { "","10123","12345","00123" };
	char studName[4][100] = { "","Bryan Law","James Chow","Tan Ah Gaw" };
	float cgpa[4] = { 0, 2.95, 3.25, 3.75 };
	int ret;

	puts("View student's CGPA : \n");
	printf("Enter student ID (eg. KPKL12345) > KPKL");
	scanf("%s", &studID);

	//Output
	if (strcmp(studID, studID[0]) == 1) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[0]);
		printf("Student ID        : KPKL%s\n", studID[0]);
		printf("Your CGPA         : %.2f  \n", cgpa[0]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[1]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[1]);
		printf("Student ID        : KPKL%s\n", studID[1]);
		printf("Your CGPA         : %.2f  \n", cgpa[1]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[2]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[2]);
		printf("Student ID        : KPKL%s\n", studID[2]);
		printf("Your CGPA         : %.2f  \n", cgpa[2]);
		printf("-------------------------------------------\n");
	}
	else if (strcmp(studID, studID[3]) == 0) {
		printf("-------------------------------------------\n");
		printf("Student Name      : %s\n", studName[3]);
		printf("Student ID        : KPKL%s\n", studID[3]);
		printf("Your CGPA         : %.2f  \n", cgpa[3]);
		printf("-------------------------------------------\n");
	}
	else
		printf("\nStudent ID does not exist.\n");

	//Choices for Student to choose where to go
	printf("\n");
	printf("1) View GPA\n");
	printf("2) View CGPA\n");
	printf("3) Back To Home Page\n\n");
	printf("Where would you like to go now? > ");
	scanf("%d", &ret);
	rewind(stdin);
	printf("\n");

	switch (ret) {
	case 1:
		printf("-------------------------------------------\n");
		viewgpaStudent();   //Function call viewgpaStudent()
		break;
	case 2:
		printf("-------------------------------------------\n");
		viewcgpaStudent();  //Function call viewcgpaStudent()
		break;
	case 3:
		system("CLS");
		main();    //Function call main()
		break;
	default:
		system("CLS");
		main();    //Function call main()
	}
}