#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <windows.h>
#include <stdbool.h>
#include <time.h>
#define MAX_ID_LENGTH 10
#define MAX_STAFF 100
#define LONG 1000
#define SHORT 120
#define MID 300

SYSTEMTIME t;

typedef struct {
    char from[20], to[20], startMonth[4], endMonth[4], confirmation, conti;
    int startHour, startMinute, endHour, endMinute, price, startDay, startYear, endDay, endYear, totalTicket, no;
}Schedule;

typedef struct {
    char coachNo;
    char seatNo[100];
    double price;
}Coach;

typedef struct {
    char trainid[7];
    char departfrom[20], arriveat[20];
    int startday, startyear;
    char startmonth[4];
    int trainleaveHour, trainleaveMinute;
    int endday, endyear;
    char endmonth[4];
    int etaHour, etaMinute;
    char coach;
    char seats[1000];
    char method[9];
    double paid;
    char memberId[6];
}Ticket;

typedef struct {
    char name[50];
    char gender;
    char contact[20];
    char email[30];
    char username[50];
    char password[50];
    char memberId[50];
    int age;
    char country[50];
    char birth[11];
} User;

typedef struct {
    char id[5];
    char name[30];
    char gender;
    int age;
    char birth[30];
    char email[30];
    char position[20];
    char passw[20];
    int role; //0 = staff , 1 = top
}Staff;

int homeMember(char *input_memberid[50]);
int homeStaff();

// Chin Weng Hin Part
void makeBooking(char* input_memberid[50]);             // for member
void cancelBooking(int num, char* input_memberid[50]);  // for member
void printTicket(char* input_memberid[50]);             // for member
void addSeats();                                        // for staff
void modifySeats();                                     // for staff
void deleteSeats();                                     // for staff
void srand(unsigned int seed);                          // to randomize seeds for rand()

// Ong Wen Hao Part
void colouring();                                       // for main()
void colour(char colour[70]);                           // for main()
void displaySchedule();                                 // for member and staff
void searchSchedule();                                  // for member and staff
void addSchedule();                                     // for staff
void modifySchedule();                                  // for staff
void deleteSchedule();                                  // for staff

// Koh Ke Xing Part
void deleteMember(const char* memberId);                // for member
void modifyMember();                                    // for member
void searchMember(const char* searchCondition);         // for member
void displayMember(const char* input_memberid[50]);     // for member
void feedback();                                        // for member
void loginMember(char* input_memberid[50]);             // for member
void registration();                                    // for member
void updateLastMemberId(int memberId);                  // for member
int getLastMemberId();                                  // for member
int isValidPassword(const char* password);              // for member and staff
int isValidPhoneNumber(char* phone);                    // for member and staff
int isValidEmail(char* email);                          // for member
int isValidName(char* name);                            // for member
void displayAllMembers();                               // for staff

// Eunice Lim Ni-Xi Part
void delete_staff(const char* filename);                // for staff
void addStaff();                                        // for staff
char* generateStaffId();                                // for staff
void updateLastStaffId(int newId);                      // for staff
int getLastStaffId();                                   // for staff
void modifyStaff();                                     // for staff
void searchStaff(const char* searchCondition);          // for staff
void displayStaff();                                    // for staff
int loginStaff(int* userRole);                          // for staff


char ans;
int option;


// for staff
int loginStaff(int* userRole) {
    FILE* fptr;
    FILE* top;
    Staff s;
    char input_id[50];
    char input_password[50];
    int found = 0;

    fptr = fopen("staff.txt", "r");
    top = fopen("top.txt", "r");

    if (fptr == NULL || top == NULL) {
        printf("Error opening files\n");
        return 0;
    }

    printf("\n\nWelcome To Our Choo Choo Sdn Bhd\n\n");
    printf("Please Login Your Account \n\n");

    printf("Please Enter Your ID: ");
    rewind(stdin);
    scanf("%49s", input_id);

    printf("Please Enter Your Password: ");
    rewind(stdin);
    scanf("%19s", input_password);

    // Check in staff.txt
    while (fscanf(fptr, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", s.id, s.name, &s.gender, &s.age, s.birth, s.email, s.position, s.passw) != EOF) {
        if (strcmp(s.id, input_id) == 0 && strcmp(s.passw, input_password) == 0) {
            printf("\nStaff ID  Name\t\t  Gender  Age\tBirth Date\tEmail\t\t        Position\n");
            printf("--------  --------------- ------ ----\t----------\t------------------\t-------------------\n");
            printf("%s      %s %c\t  %d\t%s\t%s\t%s\t\t\t\n\n", s.id, s.name, s.gender, s.age, &s.birth, &s.email, s.position);
            printf("\n");
            printf("\n");
            *userRole = 0; // Staff role
            found = 1;
            break;
        }
    }

    // Check in top.txt
    if (!found) {
        while (fscanf(top, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", s.id, s.name, &s.gender, &s.age, s.birth, s.email, s.position, s.passw) != EOF) {
            if (strcmp(s.id, input_id) == 0 && strcmp(s.passw, input_password) == 0) {
                printf("\nStaff ID  Name\t\t  Gender  Age\tBirth Date\tEmail\t\t        Position\n");
                printf("--------  --------------- ------ ----\t----------\t------------------\t-------------------\n");
                printf("%s      %s %c\t  %d\t%s\t%s\t%s\t\t\t\n\n", s.id, s.name, s.gender, s.age, &s.birth, &s.email, s.position);
                printf("\n");
                printf("\n");
                *userRole = 1; // Top management role
                found = 1;
                break;
            }
        }
    }

    fclose(fptr);
    fclose(top);

    if (!found) {
        printf("\nLogin Failed!!!\n\n");
        
        system("pause");
        system("cls");
        return 0;
    }

    printf("Login Successful!!!\n");
    return 1; // Return 1 to indicate successful login
}

// for staff
void displayStaff() {
    FILE* fptr;
    Staff s;

    fptr = fopen("staff.txt", "r");

    if (fptr == NULL) {
        printf("Error");
        exit(-1);
    }

    printf("\nStaff ID  Name\t\t  Gender  Age\t Birth Date\t Email\t\t         Position\n");
    printf("--------  --------------- ------ ----\t ----------\t ------------------\t -------------------\n");

    while (fscanf(fptr, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", &s.id, &s.name, &s.gender, &s.age, &s.birth, &s.email, &s.position, &s.passw) != EOF) {
        printf("%s      %s %c\t  %d\t %s\t %s\t %s\n", s.id, s.name, s.gender, s.age, &s.birth, &s.email, s.position);
    }

    fclose(fptr);
}

// for staff
void searchStaff(const char* searchCondition) {
    Staff s;
    FILE* fptr;
    int found = 0;

    fptr = fopen("staff.txt", "r");

    if (fptr == NULL) {
        printf("unable open the file\n");
        exit(-1);
    }
    while (fscanf(fptr, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", &s.id, &s.name, &s.gender, &s.age, &s.birth, &s.email, &s.position, &s.passw) != EOF) {
        if (strcmp(s.id, searchCondition) == 0 || strcmp(s.name, searchCondition) == 0) {
            printf("\nStaff ID : %s\n", s.id);
            printf("Name     : %s\n", s.name);
            printf("Gender   : %c\n", s.gender);
            printf("Age      : %d\n", s.age);
            printf("Birth    : %s\n", s.birth);
            printf("Email    : %s\n", s.email);
            printf("Position : %s\n", s.position);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("No matching records found.\n");
    }
    fclose(fptr);
}

// for staff
void modifyStaff() {
    FILE* fptr;
    FILE* tempFile;
    Staff s;
    char searchCondition[50];
    int found = 0;

    fptr = fopen("staff.txt", "r");
    tempFile = fopen("temp.txt", "w");

    if (fptr == NULL || tempFile == NULL) {
        printf("Unable to open the file\n");
        exit(EXIT_FAILURE);
    }

    printf("Enter Staff ID to Modify: ");
    scanf("%49s", searchCondition);

    while (fscanf(fptr, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", &s.id, &s.name, &s.gender, &s.age, &s.birth, &s.email, &s.position, &s.passw) != EOF) {
        if (strcmp(s.id, searchCondition) == 0 || strcmp(s.name, searchCondition) == 0) {
            printf("\nEditing record for: %s\n", s.name);

            printf("\nCurrent Email     : %s\n", s.email);
            printf("Enter new email   : ");
            scanf("%s", s.email);

            printf("\nCurrent Position  : %s\n", s.position);
            printf("Enter new position: ");
            scanf("%s", s.position);

            printf("\nCurrent Password  : %s\n", s.passw);
            printf("Enter new password: ");
            scanf("%s", s.passw);

            found = 1;
        }
        fprintf(tempFile, "%s|%s| %c|%d|%s|%s|%s|%s\n", s.id, s.name, s.gender, s.age, s.birth, s.email, s.position, s.passw);
    }

    fclose(fptr);
    fclose(tempFile);

    if (found) {
        remove("staff.txt");
        rename("temp.txt", "staff.txt");
        printf("\nStaff details updated successfully.\n");
    }
    else {
        remove("temp.txt");
        printf("No matching records found to modify.\n");
    }
}

// Function to get the last staff ID
int getLastStaffId() {
    int lastId = 10; // Start from 10 if the file doesn't exist
    FILE* fp = fopen("lastStaffId.txt", "r");
    if (fp != NULL) {
        fscanf(fp, "%d", &lastId);
        fclose(fp);
    }
    else {
        // If the file doesn't exist, create it and write the initial value
        fp = fopen("lastStaffId.txt", "w");
        if (fp != NULL) {
            fprintf(fp, "%d", lastId);
            fclose(fp);
        }
    }
    return lastId;
}

// Function to update the last staff ID
void updateLastStaffId(int newId) {
    FILE* fp = fopen("lastStaffId.txt", "w");
    if (fp != NULL) {
        fprintf(fp, "%d", newId);
        fclose(fp);
    }
}

// for staff
char* generateStaffId() {
    static char staffId[6]; // Assuming IDs are like "S0001", "S0002", ...
    int lastId = getLastStaffId();
    int newId = lastId + 1;
    sprintf(staffId, "S%04d", newId);
    updateLastStaffId(newId);
    return staffId;
}

// Function to add a new staff record
void addStaff() {
    Staff s;
    FILE* fptr = fopen("staff.txt", "r");
    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(EXIT_FAILURE);
    }

    // Generate a new staff ID
    int newId = getLastStaffId() + 1;
    sprintf(s.id, "S%04d", newId);

    // Input new staff details
    printf("Enter Name: ");
    rewind(stdin);
    scanf("%49s", &s.name); // Using %49s to prevent buffer overflow

    printf("Enter Gender (M/F): ");
    rewind(stdin);
    scanf(" %c", &s.gender);

    printf("Enter Age: ");
    rewind(stdin);
    scanf("%d", &s.age);

    printf("Enter Birth Date (DD/MM/YYYY): ");
    rewind(stdin);
    scanf("%29s", &s.birth);

    printf("Enter Email: ");
    rewind(stdin);
    scanf("%29s", &s.email);

    // Validate the email format
    if (!isValidEmail(s.email)) {
        printf("Invalid email format!\n");
        return;
    }

    printf("Enter Position: ");
    rewind(stdin);
    scanf("%19s", &s.position);

    printf("Enter Password: ");
    rewind(stdin);
    scanf("%19s", &s.passw);

    fclose(fptr);

    // Open the file in append mode to add the new record
    fptr = fopen("staff.txt", "a");
    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(EXIT_FAILURE);
    }

    // Write the new staff record to the file
    fprintf(fptr, "%s|%s|%c|%d|%s|%s|%s|%s\n", s.id, s.name, s.gender, s.age, s.birth, s.email, s.position, s.passw);
    fclose(fptr);

    // Update the last staff ID
    updateLastStaffId(newId);

    printf("\nRecord added successfully!\n");
}

// Function to delete a staff member by ID from a file
void delete_staff(const char* filename) {
    FILE* file, * tempFile;
    Staff s;
    char staff_id_to_delete[MAX_ID_LENGTH];
    int found = 0;

    // Open the original file for reading
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    // Create a temporary file to store the updated list
    tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        perror("Error opening temporary file");
        fclose(file);
        return;
    }

    // Get the staff ID to delete from the admin
    printf("Enter Staff ID to delete: ");
    scanf("%s", staff_id_to_delete);

    // Read staff records and write to the temp file, excluding the one to delete
    while (fscanf(file, "%[^|]|%[^|]| %c |%d |%[^|]|%[^|]|%[^|]|%s\n", s.id, s.name, &s.gender, &s.age, s.birth, s.email, s.position, s.passw) != EOF) {
        if (strcmp(s.id, staff_id_to_delete) != 0) {
            fprintf(tempFile, "%s|%s|%c|%d|%s|%s|%s|%s\n", s.id, s.name, s.gender, s.age, s.birth, s.email, s.position, s.passw);
        }
        else {
            found = 1;
        }
    }

    fclose(file);
    fclose(tempFile);

    // Replace the original file with the updated list if a record was deleted
    if (found) {
        remove(filename);
        rename("temp.txt", filename);
        printf("Staff ID %s has been deleted.\n", staff_id_to_delete);
    }
    else {
        remove("temp.txt");
        printf("Staff ID %s not found.\n", staff_id_to_delete);
    }
}

// home for Staff after login
int homeStaff() {
    int userRole = -1; // Default to -1, meaning no role
    int loggedIn = loginStaff(&userRole); // Attempt to login and get the user role
    int choice;

    if (loggedIn) {
        do {
            // Display the menu based on user role
            printf("\n\n\t\t\t\t\t\tWelcome To Our Coo Coo Sdn Bhd\n\n");
            printf("\t\t\t\t\t  ------------------------------------------\n\n");
            printf("\t\t\t\t\t           1. Display Staff Details\n");
            printf("\t\t\t\t\t           2. Search Staff\n");
            printf("\t\t\t\t\t           3. Display All Member Details\n");
            printf("\t\t\t\t\t           4. Search Member\n");
            printf("\t\t\t\t\t           5. Display Train Schedule\n");
            printf("\t\t\t\t\t           6. Add Train Schedule\n");
            printf("\t\t\t\t\t           7. Search Train Schedule\n");
            printf("\t\t\t\t\t           8. Modify Train Schedule\n");
            printf("\t\t\t\t\t           9. Delete Train Schedule\n");
            printf("\t\t\t\t\t          10. Add Train Seats\n");
            printf("\t\t\t\t\t          11. Modify Train Seats\n");
            printf("\t\t\t\t\t          12. Delete Train Seats\n");
            if (userRole == 1) {
                printf("\t\t\t\t\t          13. Modify Staff\n");
                printf("\t\t\t\t\t          14. Add Staff\n");
                printf("\t\t\t\t\t          15. Delete Staff\n");
                printf("\t\t\t\t\t          16. Logout\n");
                printf("\n\t\t\t\t\t  ------------------------------------------\n\n");
            }
            else {
                printf("\t\t\t\t\t          13. Add Staff\n");
                printf("\t\t\t\t\t          14. Logout\n");
                printf("\n\t\t\t\t\t  ------------------------------------------\n\n");
            }
            printf("Enter your choice: ");
            scanf("%d", &choice);
            while ((getchar()) != '\n'); // Clear the input buffer

            char searchCondition[50]; // Buffer for search condition

            switch (choice) {
            case 1:
                displayStaff();
                break;
            case 2:
                if (userRole == 1) {
                    printf("Enter Staff ID: ");
                    scanf("%49s", searchCondition);
                    searchStaff(searchCondition);
                }
                else {
                    printf("Enter Staff ID: ");
                    scanf("%49s", searchCondition);
                    searchStaff(searchCondition);
                }
                break;
            case 3:
                displayAllMembers();
                break;
            case 4:
                printf("\nSearch Member  :  ");
                printf("Please Enter Member ID > ");
                rewind(stdin);
                scanf("%s", searchCondition);
                searchMember(searchCondition);
                break;
            case 5:
                displaySchedule();
                break;
            case 6:
                addSchedule();
                break;
            case 7:
                searchSchedule();
                break;
            case 8:
                modifySchedule();
                break;
            case 9:
                deleteSchedule();
                break;
            case 10:
                addSeats();
                break;
            case 11:
                modifySeats();
                break;
            case 12:
                deleteSeats();
                break;
            case 13:
                if (userRole == 1) {
                    modifyStaff();
                }
                else {
                    addStaff();
                }
                break;
            case 14:
                if (userRole == 1) {
                    addStaff();
                }
                else {
                    printf("\nExiting...  ");
                    choice = 14; // To exit for staff
                }
                break;
            case 15:
                if (userRole == 1) {
                    delete_staff("staff.txt");
                }
                else {
                    printf("Invalid choice. Please try again.\n");
                }
                break;
            case 16:
                if (userRole == 1) {
                    printf("\nExiting...  ");
                    choice = 16; // To exit for staff
                }
                else {
                    printf("Invalid choice. Please try again.\n");
                }
                break;
            default:
                printf("Invalid choice. Please try again.\n");
            }

            // Pause and wait for the user to press a key before returning to the menu
            if ((userRole == 1 && choice == 16) || (userRole != 1 && choice == 14)) {
                printf("\nPress Enter to return to the main menu...");
                while ((getchar()) != '\n'); // Wait for the user to press Enter
            }

        } while ((userRole == 1 && choice != 16) || (userRole != 1 && choice != 14));
    }

    return 0;
}


// Function to check if name is valid
int isValidName(char* name) {
    for (int i = 0; name[i]; i++) {
        if (!isalpha(name[i]) && name[i] != ' ' && name[i] != '-') {
            return 0;
        }
    }
    return 1; // All characters are valid
}

// Function to check if the email is valid
int isValidEmail(char* email) {
    char* at = strchr(email, '@'); // no '@' symbol
    if (at == NULL) return 0; // No '.' after '@'
    return 1;
}

// Function to check if the phone number is valid
int isValidPhoneNumber(char* phone) {
    int len = strlen(phone);
    for (int i = 0; i < len; i++) {
        if (!isdigit(phone[i])) {
            if (phone[i] != '-' && phone[i] != ' ') { // Allow hyphens and spaces
                return 0; // Non-digit character found
            }
        }
    }
    return len == 11; // Check the length after removing non-digit characters
}

// Check if the password is valid
int isValidPassword(const char* password) {
    int len = strlen(password);
    int hasAlphabet = 0;
    int hasNumber = 0;
    int hasSpecialChar = 0;

    if (len < 8 || len > 20) {
        return 0;
    }
    for (int i = 0; i < len; i++) {
        if (isalpha(password[i])) {
            hasAlphabet = 1;
        }
        else if (isdigit(password[i])) {
            hasNumber = 1;
        }
        else if (!isalnum(password[i])) {
            hasSpecialChar = 1;
        }
    }
    // Check if all required components are present
    return hasAlphabet && hasNumber && hasSpecialChar;
}


// for member
int getLastMemberId() {
    int lastId = 0;
    FILE* fp;
    fp = fopen("lastMemberId.txt", "r");
    if (fp != NULL) {
        fscanf(fp, "%d", &lastId);
        lastId++;
        fclose(fp);
    }
    return lastId;
}

// for member
void updateLastMemberId(int memberId) {
    FILE* fp;
    fp = fopen("lastMemberId.txt", "w");
    if (fp != NULL) {
        fprintf(fp, "%d", memberId);
        fclose(fp);
    }
}

// for member
void registration() {
    FILE* fptr;
    User u;

    fptr = fopen("registration.txt", "a");
    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(-1);
    }
    printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
    printf("\t\t\t\t\t  Let's Register To become Our Member !!!\n");
    printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");

    printf("\n\nPlease Enter User Information For Registration\n");
    printf("------------------------------------------------\n\n");

    // Get the last member ID
    int lastId = getLastMemberId();

    // Generate new member ID
    int newId = lastId + 1;
    sprintf(u.memberId, "M%03d", newId);

    do {
        printf("Please Enter Your Name > ");
        rewind(stdin);
        scanf(" %[^\n]", u.name);
        if (!isValidName(u.name)) {
            printf("Invalid Name. Please Enter A Valid Name.\n");
        }
    } while (!isValidName(u.name));

    printf("Please Enter Your Gender (F or M) > ");
    scanf(" %c", &u.gender);

    do {
        printf("Please Enter Your Age:");
        scanf("%d", &u.age);
    } while (u.age <= 0 || u.age > 100);

    printf("Please Enter Your Birth (DD-MM-YYYY) > ");
    scanf("%s", &u.birth);

    printf("Please Enter Your Country > ");
    rewind(stdin);
    scanf("%[^\n]", &u.country);

    do {
        printf("Please Enter Your Contact Number > ");
        scanf(" %[^\n]", u.contact);
        if (!isValidPhoneNumber(u.contact)) {
            printf("Invalid Phone Number. Please Enter A Valid Phone Number.\n");
        }
    } while (!isValidPhoneNumber(u.contact));

    do {
        printf("Please Enter Your Email > ");
        scanf(" %[^\n]", u.email);
        if (!isValidEmail(u.email)) {
            printf("Invalid Email. Please Enter A Valid Email.\n");
        }
    } while (!isValidEmail(u.email));

    printf("Please Enter Your Username > ");
    scanf(" %[^\n]", &u.username);

    do {
        printf("Please Enter Your Password > ");
        scanf(" %[^\n]", &u.password);
        if (!isValidPassword(u.password)) {
            printf("Invalid Password.\nPassword should contain 8 to 20 characters, including alphabets, numbers, and special characters.\n");
        }
    } while (!isValidPassword(u.password));

    // Write new member details to file
    fprintf(fptr, "%s|%c|%d|%s|%s|%s|%s|%s|%s|%s\n", u.name, u.gender, u.age, u.birth, u.country, u.contact, u.email, u.username, u.password, u.memberId);

    fclose(fptr);

    // Update last member ID
    updateLastMemberId(newId);

    printf("\n==========================\n");
    printf(" Registration successful!\n");
    printf("  Your Member ID is %s\n", u.memberId);
    printf("==========================\n\n");
}

// for member
void loginMember(char* input_memberid[50]) {
    FILE* fptr;
    User u;
    char input_username[50];
    char input_password[50];
    int found = 0;

    fptr = fopen("registration.txt", "r");
    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(-1);
    }

    printf("\n Please Login Your Account \n");
    printf("---------------------------\n\n");

    printf("Please Enter Your Username: ");
    rewind(stdin);
    scanf("%[^\n]", &input_username);

    printf("Please Enter Your Password: ");
    rewind(stdin);
    scanf("%s", &input_password);

    while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u.name, &u.gender, &u.age, &u.birth, &u.country, &u.contact, &u.email, &u.username, &u.password, &u.memberId) != EOF) {
        if (strcmp(u.username, input_username) == 0 && strcmp(u.password, input_password) == 0) {
            printf("\n - - - - - - - - - - - \n");
            printf("| Login Successful!!! |\n");
            printf(" - - - - - - - - - - - \n\n");
            strcpy(input_memberid, u.memberId);
            found = 1;
            break;
        }
    }
    if (found != 1) {
        printf("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        printf("| Login Failed. Username or Password may be incorrect, please try again later... |\n");
        printf("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n\n");
        system("pause");
        system("cls");
        main();
    }
    fclose(fptr);
}

// for member
void feedback() {
    FILE* fptr;
    User u;
    int rating;
    char review[1000];
    fptr = fopen("feedback.txt", "a");
    if (fptr == NULL) {
        printf("unable open the file\n");
        exit(-1);
    }

    printf("\n<---- Please Give Us Your Review ---->\n");
    printf("< Your Feedback Are Important For Us >\n\n");

    printf("Please Enter Your Member ID > ");
    scanf("%s", u.memberId);

    printf("Please Enter Your Username > ");
    scanf("%s", u.username);

    printf("Please Give The Rating (1 - 5) > ");
    scanf("%d", &rating);

    rewind(stdin);
    printf("Please Write Your Review > ");
    scanf("%[^\n]", review);

    fprintf(fptr, "%s\t\t%s\t\t%d\t\t%s\n", u.memberId, u.username, rating, review);

    printf("\n====================================================\n");
    printf(" Your Feedback Form Has Been Submitted Successfully\n");
    printf("             Thanks For Your Feedback!             \n");
    printf("====================================================\n\n");

    fclose(fptr);
}

// for member
void displayMember(const char* input_memberid[50]) {
    User u;
    GetLocalTime(&t);
    int found = 0;
    FILE* fptr;
    fptr = fopen("registration.txt", "r");
    if (fptr == NULL) {
        printf("Unable open the file\n");
        exit(-1);
    }
    printf("\n Member Details \n");
    printf("================\n");

    while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u.name, &u.gender, &u.age, &u.birth, &u.country, &u.contact, &u.email, &u.username, &u.password, &u.memberId) != EOF) {
        if (strcmp(u.memberId, input_memberid) == 0 || strcmp(u.username, input_memberid) == 0) {

            printf("Member ID    : %s\n", u.memberId);
            printf("Username     : %s\n", u.username);
            printf("Name         : %s\n", u.name);
            printf("Gender       : %c\n", u.gender);
            printf("Age          : %d\n", u.age);
            printf("Birth        : %s\n", u.birth);
            printf("Country      : %s\n", u.country);
            printf("Phone Number : %s\n", u.contact);
            printf("Email        : %s\n\n", u.email);
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("Member ID %s not found.\n", input_memberid);
    }

    fclose(fptr);

}

// for member
void searchMember(const char* searchCondition) {
    User u;
    FILE* fptr;
    GetLocalTime(&t);
    int found = 0;
    fptr = fopen("registration.txt", "r");
    if (fptr == NULL) {
        printf("unable open the file\n");
        exit(-1);
    }
    printf("\n Member Details \n");
    printf("================\n");
    while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u.name, &u.gender, &u.age, &u.birth, &u.country, &u.contact, &u.email, &u.username, &u.password, &u.memberId) != EOF) {

        if (strcmp(u.memberId, searchCondition) == 0 || strcmp(u.username, searchCondition) == 0) {
            printf("\nMember ID    : %s\n", u.memberId);
            printf("Username     : %s\n", u.username);
            printf("Name         : %s\n", u.name);
            printf("Gender       : %c\n", u.gender);
            printf("Age          : %d\n", u.age);
            printf("Birth        : %s\n", u.birth);
            printf("Country      : %s\n", u.country);
            printf("Phone Number : %s\n", u.contact);
            printf("Email        : %s\n\n", u.email);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("No matching records found.\n");
    }
    fclose(fptr);
}

// for member
void modifyMember() {
    User u[100];
    GetLocalTime(&t);
    FILE* fptr;
    char searchCondition[50];
    int found = 0, total = 0;
    int newage;
    char newcountry[50], newemail[30], newcontact[20];

    fptr = fopen("registration.txt", "r");
    if (fptr == NULL) {
        printf("Unable open the file\n");
        exit(-1);
    }

    printf("Enter Member ID or Username to Modify : ");
    scanf("%s", &searchCondition);

    while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u[total].name, &u[total].gender, &u[total].age, &u[total].birth, &u[total].country, &u[total].contact, &u[total].email, &u[total].username, &u[total].password, &u[total].memberId) != EOF) {

        total++;
    }

    fclose(fptr);

    for (int i = 0; i < total; i++) {
        if (strcmp(u[i].memberId, searchCondition) == 0 || strcmp(u[i].username, searchCondition) == 0) {
            printf("Editing Member Details  For : %s\n\n", u[i].name);
            printf("Current Age            > %d\n", u[i].age);
            do {
                printf("Update Age             > ");
                rewind(stdin);
                scanf("%d", &newage);
            } while (newage <= 0 || newage > 100);
            printf("\nCurrent Country        > %s\n", u[i].country);

            printf("Update Country         > ");
            rewind(stdin);
            scanf("%s", &newcountry);

            printf("\nCurrent Email          > %s\n", u[i].email);
            do {
                printf("Update Email           > ");
                rewind(stdin);
                scanf("%s", &newemail);
            } while (!isValidEmail(newemail));
            printf("\nCurrent Phone Number   > %s\n", u[i].contact);
            do {
                printf("Update Phone Number    > ");
                rewind(stdin);
                scanf("%s", &newcontact);
            } while (!isValidPhoneNumber(newcontact));

            u[i].age = newage;
            strcpy(u[i].country, newcountry);
            strcpy(u[i].email, newemail);
            strcpy(u[i].contact, newcontact);
            found = 1;
        }
    }

    FILE* pptr;
    pptr = fopen("registration.txt", "w");
    if (pptr == NULL) {
        printf("Unable open the file\n");
        exit(-1);
    }

    for (int j = 0; j < total; j++) {
        fprintf(pptr, "%s|%c|%d|%s|%s|%s|%s|%s|%s|%s\n", u[j].name, u[j].gender, u[j].age, u[j].birth, u[j].country, u[j].contact, u[j].email, u[j].username, u[j].password, u[j].memberId);
    }

    fclose(pptr);

    if (found == 1) {

        printf("\n==========================================");
        printf("\n Member Details Are Updated Successfully.\n");
        printf("==========================================\n");

        int count = 0;

        FILE* rptr;
        rptr = fopen("registration.txt", "r");
        if (rptr == NULL) {
            printf("Unable open the file\n");
            exit(-1);
        }
        printf("\n Updated Member Details\n");
        printf("========================\n\n");

        while (fscanf(rptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u[count].name, &u[count].gender, &u[count].age, &u[count].birth, &u[count].country, &u[count].contact, &u[count].email, &u[count].username, &u[count].password, &u[count].memberId) != EOF) {
            if (strcmp(u[count].memberId, searchCondition) == 0 || strcmp(u[count].username, searchCondition) == 0) {

                printf("Member ID    : %s\n", u[count].memberId);
                printf("Username     : %s\n", u[count].username);
                printf("Name         : %s\n", u[count].name);
                printf("Gender       : %c\n", u[count].gender);
                printf("Age          : %d\n", u[count].age);
                printf("Birth        : %s\n", u[count].birth);
                printf("Country      : %s\n", u[count].country);
                printf("Phone Number : %s\n", u[count].contact);
                printf("Email        : %s\n\n", u[count].email);
                found = 1;
                break;
            }
            count++;
        }
        fclose(rptr);
    }
    else if (found < 1){
        printf("\nNo Matching Records Found To Modify.\n");
    }

}

// for member
void deleteMember(const char* memberId) {

    User u[100];
    int current, total = 0, found = 0, i;

    FILE* fptr;
    FILE* pptr;
    char confirmation;

    fptr = fopen("registration.txt", "r");

    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(-1);
    }

    printf("Are You Sure Want To Delete Your Account? (Y/N) :");
    rewind(stdin);
    scanf(" %c", &confirmation);

    if (confirmation == 'Y' || confirmation == 'y') {

        
        while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u[total].name, &u[total].gender, &u[total].age, &u[total].birth, &u[total].country, &u[total].contact, &u[total].email, &u[total].username, &u[total].password, &u[total].memberId) != EOF) {
            total++;
        }
        fclose(fptr);

        for (i = 0; i < total; i++) {
            if (strcmp(u[i].memberId, memberId) == 0) {
                found = 1;
                break; // Stop searching if found
            }
        }

        for (current = i; current < total - 1; current++) {
            strcpy(u[current].name, u[current + 1].name);
            u[current].gender = u[current + 1].gender;
            u[current].age = u[current + 1].age;
            strcpy(u[current].birth, u[current + 1].birth);
            strcpy(u[current].country, u[current + 1].country);
            strcpy(u[current].contact, u[current + 1].contact);
            strcpy(u[current].email, u[current + 1].email);
            strcpy(u[current].username, u[current + 1].username);
            strcpy(u[current].password, u[current + 1].password);
            strcpy(u[current].memberId, u[current + 1].memberId);
        }

        total--;

        pptr = fopen("registration.txt", "w");
        if (pptr == NULL) {
            printf("Unable to open the file\n");
            exit(-1);
        }

        for (i = 0; i < total; i++) {
            fprintf(pptr, "%s|%c|%d|%s|%s|%s|%s|%s|%s|%s\n", u[i].name, u[i].gender, u[i].age, u[i].birth, u[i].country, u[i].contact, u[i].email, u[i].username, u[i].password, u[i].memberId);
        }
        fclose(pptr);

        printf("\nAccount deleted successfully.\n\n");


        system("pause");
        system("cls");

        main();
    }
    else {
        printf("Account deletion cancelled.\n");
    }
}

// Display All Member in staff
void displayAllMembers() {
    User u;
    FILE* fptr;
    GetLocalTime(&t);

    fptr = fopen("registration.txt", "r");
    if (fptr == NULL) {
        printf("Unable to open the file\n");
        exit(-1);
    }

    printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n\n");
    printf("\t\t\t\t\t\t Welcome To Our Choo Choo Sdn Bhd\n\n");
    printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n\n");
    printf("\t\t\t\t\tMember Details - as at %d - %d -%d %d:%d\n\n", t.wDay, t.wMonth, t.wYear, t.wHour, t.wMinute);

    printf("========================================================================================================================\n");
    printf("Member ID  Username      Name              Gender     Age     Birth      Country     Phone Number           Email\n");
    printf("========================================================================================================================\n");

    while (fscanf(fptr, "%[^|]|%c|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^\n]\n", &u.name, &u.gender, &u.age, &u.birth, &u.country, &u.contact, &u.email, &u.username, &u.password, &u.memberId) != EOF) {
        printf("%-10s  %-10s  %-20s  %c       %-3d   %-12s %-10s %-15s%-20s\n", u.memberId, u.username, u.name, u.gender, u.age, u.birth, u.country, u.contact, u.email);
    }

    printf("=========================================================================================================================\n");

    fclose(fptr);
}

// home for member after login
int homeMember(char* input_memberid[50]) {
    int choice;

    char searchCondition[50];

    do {
        printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
        printf("\t\t\t\t\t\t  Welcome To Our Coo Coo Sdn Bhd\n");
        printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
        printf("\t\t\t\t\t           1. Display Member Details\n");
        printf("\t\t\t\t\t           2. Search Member\n");
        printf("\t\t\t\t\t           3. Modify Member Details\n");
        printf("\t\t\t\t\t           4. Display Train Schedule\n");
        printf("\t\t\t\t\t           5. Search Train Schedule\n");
        printf("\t\t\t\t\t           6. Book Train Ticket\n");
        printf("\t\t\t\t\t           7. Print Train Ticket\n");
        printf("\t\t\t\t\t           8. Feedback\n");
        printf("\t\t\t\t\t           9. Delete Account\n");
        printf("\t\t\t\t\t          10. Logout\n");
        printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
        printf("Please enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            displayMember(input_memberid);
            break;
        case 2:
            printf("\nSearch Member  :  ");
            printf("Please Enter Member ID > ");
            rewind(stdin);
            scanf("%s", searchCondition);
            searchMember(searchCondition);
            break;
        case 3:
            modifyMember();
            break;
        case 4:
            displaySchedule();
            break;
        case 5:
            searchSchedule();
            break;
        case 6:
            makeBooking(input_memberid);
            break;
        case 7:
            printTicket(input_memberid);
            break;
        case 8:
            feedback();
            break;
        case 9:
            deleteMember(input_memberid);
            break;
        case 10:
            printf("\n=================================================\n");
            printf(" Thanks for using Choo Choo Sdn Bhd Train System \n");
            printf("=================================================\n\n");
            system("pause");
            system("cls");
            main();
            break;
        default:
            printf("Invalid Choice. Please Enter A Number Between 1 to 6.\n");
        }
    } while (choice != 10);

}

// for staff
void addSeats() {

    Coach coachSeats;
    char coach;

    FILE* ptr;
    ptr = fopen("coach.dat", "rb");
    if (ptr == NULL) {
        printf("Unable to open coach.dat file. Please try again");
        exit(-1);
    }
    puts("\n                                     <---- Train Seats Available ---->                             ");
    puts("==========================================================================================================");
    puts("||  Coach Code  ||                            Seats Available                             ||    Price   ||");
    puts("==========================================================================================================");

    while (fread(&coachSeats, sizeof(coachSeats), 1, ptr) != 0) {
        printf("||   Coach  %c   || %-70s ||  RM %.2lf  ||\n", coachSeats.coachNo, coachSeats.seatNo, coachSeats.price);
    }
    puts("==========================================================================================================");

    fclose(ptr);

    FILE* fptr;

    fptr = fopen("coach.dat", "ab");

    puts("\n                      <------------------- Add New Train Seats ------------------->                             ");

    do {
        printf("Enter New Coach Code (A, B, C, ..) > ");
        rewind(stdin);
        scanf("%c", &coach);

        coachSeats.coachNo = toupper(coach);

        do {
            printf("Enter Seats available in Coach %c (A1, A2, A3, B1, B2, ..) [MAX 20] > ", coachSeats.coachNo);
            rewind(stdin);
            scanf("%[^\n]", &coachSeats.seatNo);
            if (strlen(coachSeats.seatNo) > 70) {
                printf("\n=================================\n");
                printf(" Exceeded maximum seat capacity!\n");
                printf("=================================\n\n");
            }
            else
                break;
        } while (strlen(coachSeats.seatNo) > 70);

        printf("Enter price per seat in Coach %c > ", coachSeats.coachNo);
        rewind(stdin);
        scanf("%lf", &coachSeats.price);


        fwrite(&coachSeats, sizeof(coachSeats), 1, ptr);

        puts("\n ** Seats Successfully Added **\n");

        printf("Enter more seats ( Y = yes | N = no ) ? > ");
        rewind(stdin);
        scanf("%c", &ans);

    } while (toupper(ans) == 'Y');

    fclose(fptr);
}

// for staff
void modifySeats() {
    
    Coach seating[100];
    char coachNo, desc;
    int count = 0, no;
    int i, current, total = 0;

    FILE* ptr;
    ptr = fopen("coach.dat", "rb");
    if (ptr == NULL) {
        printf("Unable to open coach.dat file. Please try again");
        exit(-1);
    }

    while (fread(&seating[total], sizeof(seating[total]), 1, ptr) != 0) {
        total++;
    }

    fclose(ptr);

    do {

        puts("\n                                     <---- Train Seats Available ---->                             ");
        puts("===========================================================================================================");
        puts("||  Coach Code  ||                            Seats Available                             ||    Price    ||");
        puts("===========================================================================================================");

        for (i = 0; i < total; i++) {
            printf("||   Coach  %c   || %-70s ||  RM %6.2lf  ||\n", seating[i].coachNo, seating[i].seatNo, seating[i].price);
        }
        puts("===========================================================================================================");

        count = 0;

        puts("\n                 <------------------- Update Existing Train Seats ------------------->                   ");

        printf("Enter Coach Code wanted to be updated (A, B, C, ..) > ");
        rewind(stdin);
        scanf("%c", &coachNo);

        coachNo = toupper(coachNo);

        puts("\n                                     <---- Train Seats Available ---->                             ");
        puts("===========================================================================================================");
        puts("||  Coach Code  ||                            Seats Available                             ||    Price    ||");
        puts("===========================================================================================================");
        for (no = 0; no < total; no++) {
            count++;
            if (seating[no].coachNo == coachNo) {
                printf("||   Coach  %c   || %-70s ||  RM %6.2lf  ||\n", seating[no].coachNo, seating[no].seatNo, seating[no].price);
                break;
            }
        }
        puts("===========================================================================================================\n");

        printf("Do you want to modify this record? ( Y = yes | N = no ) > ");
        rewind(stdin);
        scanf("%c", &desc);

        desc = toupper(desc);

        if (desc == 'Y') {

            int found = 0;
            char newseats[1000];
            double newprice;

            printf("Coach Code > %c\n", seating[no].coachNo);

            printf("Seats Available > ");
            rewind(stdin);
            scanf("%[^\n]", &newseats);

            printf("Price > RM ");
            rewind(stdin);
            scanf("%lf", &newprice);

            strcpy(seating[no].seatNo, newseats);
            seating[no].price = newprice;

            FILE* pointer;
            //open file pointer for writing
            pointer = fopen("coach.dat", "wb");
            if (pointer == NULL) {
                printf("Unable to open file coach.dat.");
                exit(-1);
            }

            //use for loop to write record by record into binary file
            for (i = 0; i < total; i++) {
                fwrite(&seating[i], sizeof(Coach), 1, pointer);
            }
            fclose(pointer);

            printf("\n================================\n");
            printf(" Train Seats has been updated. \n");
            printf("================================\n\n");

        }
        else {
            printf("\n===========================================\n");
            printf(" Update Cancelled. Please try again later. \n");
            printf("===========================================\n\n");
        }

        printf("Update more existing seats ( Y = yes | N = no ) ? > ");
        rewind(stdin);
        scanf("%c", &ans);

    } while (ans == 'Y' || ans == 'y');
}

// for staff
void deleteSeats() {

    Coach seating[100];
    char coachNo, desc;
    int count = 0, no;
    int i, current, total = 0;

    FILE* ptr;
    ptr = fopen("coach.dat", "rb");
    if (ptr == NULL) {
        printf("Unable to open coach.dat file. Please try again");
        exit(-1);
    }

    while (fread(&seating[total], sizeof(seating[total]), 1, ptr) != 0) {
        total++;
    }

    fclose(ptr);

    do {

        puts("\n                                     <---- Train Seats Available ---->                             ");
        puts("===========================================================================================================");
        puts("||  Coach Code  ||                            Seats Available                             ||    Price    ||");
        puts("===========================================================================================================");

        for (i = 0; i < total; i++) {
            printf("||   Coach  %c   || %-70s ||  RM %6.2lf  ||\n", seating[i].coachNo, seating[i].seatNo, seating[i].price);
        }
        puts("===========================================================================================================");

        count = 0;

        puts("\n                 <------------------- Delete Existing Train Seats ------------------->                   ");

        printf("Enter Coach Code wanted to be deleted (A, B, C, ..) > ");
        rewind(stdin);
        scanf("%c", &coachNo);

        coachNo = toupper(coachNo);

        puts("\n                                     <---- Train Seats Available ---->                             ");
        puts("===========================================================================================================");
        puts("||  Coach Code  ||                            Seats Available                             ||    Price    ||");
        puts("===========================================================================================================");
        for (no = 0; no < total; no++) {
            count++;
            if (seating[no].coachNo == coachNo) {
                printf("||   Coach  %c   || %-70s ||  RM %6.2lf  ||\n", seating[no].coachNo, seating[no].seatNo, seating[no].price);
                break;
            }
        }
        puts("===========================================================================================================\n");

        printf("Are you sure you wanted to delete this record? ( Y = yes | N = no ) > ");
        rewind(stdin);
        scanf("%c", &desc);

        desc = toupper(desc);

        if (desc == 'Y') {

            int found = 0;
            // Find the index of the record to delete
            for (current = 0; current < total; current++) {
                if (seating[current].coachNo == coachNo) {
                    found = 1;
                    break;
                }
            }

            if (found = 1) {
                // Shift the elements after the deletion
                for (i = current; i < total - 1; i++) {
                    seating[i] = seating[i + 1];
                }

                total--; // Update total count of records
            }

            FILE* pointer;
            //open file pointer for writing
            pointer = fopen("coach.dat", "wb");
            if (pointer == NULL) {
                printf("Unable to open file coach.dat.");
                exit(-1);
            }

            //use for loop to write record by record into binary file
            for (i = 0; i < total; i++) {
                fwrite(&seating[i], sizeof(Coach), 1, pointer);
            }
            fclose(pointer);

            printf("\n================================\n");
            printf(" Train Seats has been deleted. \n");
            printf("================================\n\n");

        }
        else {
            printf("\n=============================================\n");
            printf(" Deletion Cancelled. Please try again later. \n");
            printf("=============================================\n\n");
        }

        printf("Delete more existing seats ( Y = yes | N = no ) ? > ");
        rewind(stdin);
        scanf("%c", &ans);
    
    } while (ans == 'Y' || ans == 'y');
}

// for staff
void addSchedule() {
    FILE* addPtr;
    Schedule add;
    int count = 0;

    // Open the file in read mode to count the existing records
    addPtr = fopen("schedule.txt", "rb");
    if (addPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }
    else {
        // Count the existing records
        while (fread(&add, sizeof(add), 1, addPtr) != 0) {
            count++;
        }
        fclose(addPtr);
    }

    // Open the file in append mode to add the new record
    addPtr = fopen("schedule.txt", "ab");
    if (addPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }
    else {
            add.no = count + 1;

            do {
                printf("From\t\t\t\t:");
                rewind(stdin);
                scanf("%[^\n]", add.from);
                printf("To\t\t\t\t:");
                rewind(stdin);
                scanf("%[^\n]", add.to);
                printf("Date of Journey (DD/MMM/YYYY)\t:");
                rewind(stdin);
                scanf("%d/%[^/]/%d", &add.startDay, add.startMonth, &add.startYear);
                printf("Date of Return (DD/MMM/YYYY)\t:");
                rewind(stdin);
                scanf("%d/%[^/]/%d", &add.endDay, add.endMonth, &add.endYear);
                printf("Time of Journey (HH:MM)\t\t:");
                rewind(stdin);
                scanf("%d:%d", &add.startHour, &add.startMinute);
                printf("Return of Journey (HH:MM)\t:");
                rewind(stdin);
                scanf("%d:%d", &add.endHour, &add.endMinute);
                rewind(stdin);
                
                fwrite(&add, sizeof(add), 1, addPtr);
                count++;
                printf("\nNew record has been added successfully!");

                printf("\nDo you want to continue add anything ? (Y/N) ");
                scanf("%[^\n]", &add.conti); // Remove & from &add.conti
                rewind(stdin);

                add.no++;

                
            } while (toupper(add.conti) == 'Y'); // Remove & from &add.conti   
      
    }
    fclose(addPtr);
}

// for member
void makeBooking(char* input_memberid[50]) {
    FILE* playPtr;
    int count = 0;
    Schedule add;
    Ticket trainticket;

    char memberID[6];

    strcpy(memberID, input_memberid);

    playPtr = fopen("schedule.txt", "rb");
    if (playPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }

    while (fread(&add, sizeof(add), 1, playPtr) != 0) {
        // Convert from string to uppercase
        for (int i = 0; add.from[i] != '\0'; ++i) {
            add.from[i] = toupper(add.from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; add.to[i] != '\0'; ++i) {
            add.to[i] = toupper(add.to[i]);
        }
        for (int i = 0; add.startMonth[i] != '\0'; ++i) {
            add.startMonth[i] = toupper(add.startMonth[i]);
        }
        for (int i = 0; add.endMonth[i] != '\0'; ++i) {
            add.endMonth[i] = toupper(add.endMonth[i]);
        }
    }

    fclose(playPtr);

    FILE* srcPtr;
    Schedule src[100];
    srcPtr = fopen("schedule.txt", "rb");

    char from[20], to[20];
    int no, i;


    if (srcPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }

    count = 0;
    while (fread(&src[count], sizeof(src[count]), 1, srcPtr) == 1) {
        for (i = 0; src[count].from[i] != '\0'; ++i) {
            src[count].from[i] = toupper(src[count].from[i]);
        }
        // Convert to string to uppercase
        for (i = 0; src[count].to[i] != '\0'; ++i) {
            src[count].to[i] = toupper(src[count].to[i]);
        }
        for (i = 0; src[count].startMonth[i] != '\0'; ++i) {
            src[count].startMonth[i] = toupper(src[count].startMonth[i]);
        }
        for (i = 0; src[count].endMonth[i] != '\0'; ++i) {
            src[count].endMonth[i] = toupper(src[count].endMonth[i]);
        }
        count++;
    }

    fclose(srcPtr);

    puts("\n------------------------------");
    puts(" Search for your desired trip ");
    puts("------------------------------\n");

   
    do {
        displaySchedule();

        printf("From WHERE\t\t\t> ");
        rewind(stdin);
        scanf("%[^\n]", &from);
        printf("To WHERE\t\t\t> ");
        rewind(stdin);
        scanf("%[^\n]", &to);

        for (i = 0; from[i] != '\0'; ++i) {
            from[i] = toupper(from[i]);
        }
        // Convert to string to uppercase
        for (i = 0; to[i] != '\0'; ++i) {
            to[i] = toupper(to[i]);
        }

        printf("==========================================================================================================\n");
        printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
        printf("==========================================================================================================\n");
        int found = 0;
        for (i = 0; i < count; i++) {
            if (strcmp(from, src[i].from) == 0 && strcmp(to, src[i].to) == 0) {
                found = 1;

                printf("|| %-2d  ||%-15s||%-15s|| %02d-%-3s-%-4d     || %02d-%-3s-%-4d    || %02d:%02d      || %02d:%02d    ||\n", src[i].no,
                    src[i].from, src[i].to, src[i].startDay, src[i].startMonth, src[i].startYear, src[i].endDay, src[i].endMonth, src[i].endYear,
                    src[i].startHour, src[i].startMinute, src[i].endHour, src[i].endMinute);

            }
        }
        printf("==========================================================================================================\n\n");

        if (found != 1) {
            printf("==========================================================================================================\n");
            printf("                   Sorry, no ticket available for selected trip. Please try again.\n");
            printf("==========================================================================================================\n\n");
            system("pause");
            printf("\n");
            makeBooking(input_memberid); // if no ticket available, bring user back to the start of this function to  search for other trip
        }

        printf("Choose No. of trip you want to book > ");
        scanf("%d", &no);

        // Check if the record to search exists
        for (i = 0; i < count; i++) {
            if (src[i].no == no) {
                found = 1;
                break; // Stop searching if found
            }
        }

        if (found) {
            printf("\n********** Record Found ********* \n");
            printf("==========================================================================================================\n");
            printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
            printf("==========================================================================================================\n");

            // Display the found record
            printf("|| %-2d  ||%-15s||%-15s|| %02d-%-3s-%-4d     || %02d-%-3s-%-4d    || %02d:%02d      || %02d:%02d    ||\n", src[i].no,
                src[i].from, src[i].to, src[i].startDay, src[i].startMonth, src[i].startYear, src[i].endDay, src[i].endMonth, src[i].endYear,
                src[i].startHour, src[i].startMinute, src[i].endHour, src[i].endMinute);
            printf("==========================================================================================================\n");

            Coach coachSeat;
            double totalPrice = 0;
            found = 0;

            FILE* ptr;
            ptr = fopen("coach.dat", "rb");
            if (ptr == NULL) {
                printf("Unable to open coach.dat file. Please try again");
                exit(-1);
            }

            puts("==========================================================================================================");
            puts("||  Coach Code  ||                            Seats Available                             ||    Price   ||");
            puts("==========================================================================================================");

            while (fread(&coachSeat, sizeof(coachSeat), 1, ptr) != 0) {
                printf("||   Coach  %c   || %-70s ||  RM %.2lf  ||\n", coachSeat.coachNo, coachSeat.seatNo, coachSeat.price);
                found++;
            }
            if (!found) {
                puts("||          < ---- No seats availble, Please enquire to staff for furthur information ---- >            ||");
                puts("==========================================================================================================");
                break;
            }
            puts("==========================================================================================================");

            fclose(ptr);

            do {
                printf("Choose your desired coach (A/B/C/...) > ");
                rewind(stdin);
                scanf("%c", &coachSeat.coachNo);

                coachSeat.coachNo = toupper(coachSeat.coachNo);

                if (coachSeat.coachNo < 'A' || coachSeat.coachNo > 'Z') {
                    printf("\n=======================================\n");
                    printf(" Invalid Coach Code. Please try again.");
                    printf("\n=======================================\n\n");
                }
            } while (coachSeat.coachNo < 'A' || coachSeat.coachNo > 'Z');

            char choice;
            char totalseats[100] = { "" };

            do {
                printf("Choose your desired seat in Coach %c (choose only 1 seat) > ", coachSeat.coachNo);
                rewind(stdin);
                scanf("%[^\n]", coachSeat.seatNo);

                strcat(coachSeat.seatNo, ",");

                printf("\nAny more seats wanted to book? (Y = yes | N = no ) > ");
                rewind(stdin);
                scanf("%c", &choice);

                if (coachSeat.coachNo == 'A') {
                    totalPrice += 20;
                }
                else if (coachSeat.coachNo == 'B') {
                    totalPrice += 18;
                }
                else {
                    totalPrice += 15;
                }
                strcat(totalseats, coachSeat.seatNo);
            } while (toupper(choice) == 'Y');

            printf("\n             Invoice           \n");
            printf("=================================\n");
            printf("  Member ID        > %s\n", memberID);
            printf("  Depart from      > %s\n", src[i].from);
            printf("  Arrive at        > %s\n", src[i].to);
            printf("  Departure Date   > %02d-%-3s-%-4d\n", src[i].startDay, src[i].startMonth, src[i].startYear);
            printf("  Train leave at   > %02d:%02d\n", src[i].startHour, src[i].startMinute);
            printf("  Arrival Date     > %02d-%-3s-%-4d\n", src[i].endDay, src[i].endMonth, src[i].endYear);
            printf("  ETA              > %02d:%02d\n", src[i].endHour, src[i].endMinute);
            printf("  Coach Selected   > Coach %c\n", coachSeat.coachNo);
            printf("  Seat Selected    > %s\b \n", totalseats);
            printf("  Total Price      > RM %.2lf\n", totalPrice);

            printf("\nConfirm to BOOK selected trip (Y = yes | N = no) ? > ");
            rewind(stdin);
            scanf("%c", &ans);

            if (toupper(ans) == 'Y' ) {

                int opt;
                char method[10] = { "" };
                char month[4] = { "" };

                //random generate Train ID
                time_t tr;
                srand((unsigned)time(&tr));
                int num = rand() % 8 + 1; // generate random number start from 1 until 8
                char trainid[7] = { "" };

                do {
                    printf("\nPayment\n");
                    printf("=======\n");
                    printf("1) Credit / Debit Card\n");
                    printf("2) E-wallet\n");

                    printf("\nWhich Payment Method would you prefer? (1/2) > ");
                    rewind(stdin);
                    scanf("%d", &opt);

                    switch (opt) {
                    case 1:
                        strcpy(method, "Card");
                        puts("\n - - - - - - - - - - - - -");
                        puts("| Processing Payment...   |");
                        puts(" - - - - - - - - - - - - -\n");
                        system("pause");

                        GetLocalTime(&t);

                        if (t.wMonth == 1) {
                            strcpy(month, "JAN");
                        }
                        else if (t.wMonth == 2) {
                            strcpy(month, "FEB");
                        }
                        else if (t.wMonth == 3) {
                            strcpy(month, "MAR");
                        }
                        else if (t.wMonth == 4) {
                            strcpy(month, "APR");
                        }
                        else if (t.wMonth == 5) {
                            strcpy(month, "MAY");
                        }
                        else if (t.wMonth == 6) {
                            strcpy(month, "JUN");
                        }
                        else if (t.wMonth == 7) {
                            strcpy(month, "JUL");
                        }
                        else if (t.wMonth == 8) {
                            strcpy(month, "AUG");
                        }
                        else if (t.wMonth == 9) {
                            strcpy(month, "SEP");
                        }
                        else if (t.wMonth == 10) {
                            strcpy(month, "OCT");
                        }
                        else if (t.wMonth == 11) {
                            strcpy(month, "NOV");
                        }
                        else if (t.wMonth == 12) {
                            strcpy(month, "DEC");
                        }

                        sprintf(trainid, "TRN%02d", num); //combine string and int into trainid

                        printf("\n               Receipt             \n");
                        printf("=====================================\n");
                        printf("  Member ID        > %s\n", memberID);
                        printf("  Payment Made on  > %02d-%s-%2d\n", t.wDay, month, t.wYear);
                        printf("                   > %02d:%02d (24Hour)\n", t.wHour, t.wMinute);
                        printf("  Train ID         > %s\n", trainid);
                        printf("  Depart from      > %s\n", src[i].from);
                        printf("  Arrive at        > %s\n", src[i].to);
                        printf("  Departure Date   > %02d-%-3s-%-4d\n", src[i].startDay, src[i].startMonth, src[i].startYear);
                        printf("  Train leave at   > %02d:%02d (24Hour)\n", src[i].startHour, src[i].startMinute);
                        printf("  Arrival Date     > %02d-%-3s-%-4d\n", src[i].endDay, src[i].endMonth, src[i].endYear);
                        printf("  ETA              > %02d:%02d (24Hour)\n", src[i].endHour, src[i].endMinute);
                        printf("  Coach Selected   > Coach %c\n", coachSeat.coachNo);
                        printf("  Seat Selected    > %s\b \n", totalseats);
                        printf("  Payment Method   > %s\n", method);
                        printf("  Total Paid       > RM %.2lf\n", totalPrice);

                        strcpy(trainticket.memberId, memberID);
                        strcpy(trainticket.trainid, trainid);
                        strcpy(trainticket.departfrom, src[i].from);
                        strcpy(trainticket.arriveat, src[i].to);
                        trainticket.startday = src[i].startDay;
                        strcpy(trainticket.startmonth,src[i].startMonth);
                        trainticket.startyear = src[i].startYear;
                        trainticket.trainleaveHour = src[i].startHour;
                        trainticket.trainleaveMinute = src[i].startMinute;
                        trainticket.endday = src[i].endDay;
                        strcpy(trainticket.endmonth, src[i].endMonth);
                        trainticket.endyear = src[i].endYear;
                        trainticket.etaHour = src[i].endHour;
                        trainticket.etaMinute = src[i].endMinute;
                        trainticket.coach = coachSeat.coachNo;
                        strcpy(trainticket.seats, totalseats);
                        strcpy(trainticket.method, method);
                        trainticket.paid = totalPrice;

                        FILE* eptr;
                        eptr = fopen("booking.dat", "ab");
                        if (eptr == NULL) {
                            printf("Unable to open booking.dat file. Please check again");
                            exit(-1);
                        }

                        fwrite(&trainticket, sizeof(trainticket), 1, eptr);

                        fclose(eptr);

                        printf("\n=============================================================================\n");
                        printf(" Booking Successful! Please be puntual and enter the train before it leaves!\n");
                        printf("=============================================================================\n");
                        break;
                    case 2:
                        strcpy(method, "E-wallet");
                        puts("\n - - - - - - - - - - - - -");
                        puts("| Processing Payment...   |");
                        puts(" - - - - - - - - - - - - -\n");
                        system("pause");

                        GetLocalTime(&t);

                        if (t.wMonth == 1) {
                            strcpy(month, "JAN");
                        }
                        else if (t.wMonth == 2) {
                            strcpy(month, "FEB");
                        }
                        else if (t.wMonth == 3) {
                            strcpy(month, "MAR");
                        }
                        else if (t.wMonth == 4) {
                            strcpy(month, "APR");
                        }
                        else if (t.wMonth == 5) {
                            strcpy(month, "MAY");
                        }
                        else if (t.wMonth == 6) {
                            strcpy(month, "JUN");
                        }
                        else if (t.wMonth == 7) {
                            strcpy(month, "JUL");
                        }
                        else if (t.wMonth == 8) {
                            strcpy(month, "AUG");
                        }
                        else if (t.wMonth == 9) {
                            strcpy(month, "SEP");
                        }
                        else if (t.wMonth == 10) {
                            strcpy(month, "OCT");
                        }
                        else if (t.wMonth == 11) {
                            strcpy(month, "NOV");
                        }
                        else if (t.wMonth == 12) {
                            strcpy(month, "DEC");
                        }
                        
                        sprintf(trainid, "TRN%02d", num); //combine string and int into trainid

                        printf("\n               Receipt             \n");
                        printf("=====================================\n");
                        printf("  Member ID        > %s\n", memberID);
                        printf("  Payment Made on  > %02d-%s-%2d\n", t.wDay, month, t.wYear);
                        printf("                   > %02d:%02d (24Hour)\n", t.wHour, t.wMinute);
                        printf("  Train ID         > %s\n", trainid);
                        printf("  Depart from      > %s\n", src[i].from);
                        printf("  Arrive at        > %s\n", src[i].to);
                        printf("  Departure Date   > %02d-%-3s-%-4d\n", src[i].startDay, src[i].startMonth, src[i].startYear);
                        printf("  Train leave at   > %02d:%02d (24Hour)\n", src[i].startHour, src[i].startMinute);
                        printf("  Arrival Date     > %02d-%-3s-%-4d\n", src[i].endDay, src[i].endMonth, src[i].endYear);
                        printf("  ETA              > %02d:%02d (24Hour)\n", src[i].endHour, src[i].endMinute);
                        printf("  Coach Selected   > Coach %c\n", coachSeat.coachNo);
                        printf("  Seat Selected    > %s\b \n", totalseats);
                        printf("  Payment Method   > %s\n", method);
                        printf("  Total Paid       > RM %.2lf\n", totalPrice);

                        strcpy(trainticket.memberId, memberID);
                        strcpy(trainticket.trainid, trainid);
                        strcpy(trainticket.departfrom, src[i].from);
                        strcpy(trainticket.arriveat, src[i].to);
                        trainticket.startday = src[i].startDay;
                        strcpy(trainticket.startmonth, src[i].startMonth);
                        trainticket.startyear = src[i].startYear;
                        trainticket.trainleaveHour = src[i].startHour;
                        trainticket.trainleaveMinute = src[i].startMinute;
                        trainticket.endday = src[i].endDay;
                        strcpy(trainticket.endmonth, src[i].endMonth);
                        trainticket.endyear = src[i].endYear;
                        trainticket.etaHour = src[i].endHour;
                        trainticket.etaMinute = src[i].endMinute;
                        trainticket.coach = coachSeat.coachNo;
                        strcpy(trainticket.seats, totalseats);
                        strcpy(trainticket.method, method);
                        trainticket.paid = totalPrice;

                        FILE* fptr;
                        fptr = fopen("booking.dat", "ab");
                        if (fptr == NULL) {
                            printf("Unable to open booking.dat file. Please check again");
                            exit(-1);
                        }

                        fwrite(&trainticket, sizeof(trainticket), 1, fptr);

                        fclose(fptr);

                        printf("\n=============================================================================\n");
                        printf(" Booking Successful! Please be puntual and enter the train before it leaves!\n");
                        printf("=============================================================================\n");

                        break;
                    default:
                        printf("\n========================================Invalid Input=====================================================\n");
                    }
                } while (opt < 1 || opt > 2);
            }
            else {
                printf("\n==============================================================\n");
                printf(" Booking Cancelled, you may look for another trip you prefer.\n");
                printf("==============================================================\n");
            }
        }

        if (!found) {
            printf("\n=====================================================\n");
            printf("\n Sorry, no tickets available for your selected trip.\n");
            printf("\n=====================================================\n");
        }

        printf("\nWant to make another booking (Y = yes | N = no) ? > ");
        rewind(stdin);
        scanf("%c", &ans);
        if (toupper(ans) == 'N')
            homeMember(input_memberid);

    } while (toupper(ans) == 'Y' && toupper(ans) != 'N');
}

// for member
void displaySchedule() { 
    FILE* playPtr;
    int count = 0;
    Schedule add;

    playPtr = fopen("schedule.txt", "rb");
    if (playPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }

    printf("==========================================================================================================\n");
    printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
    printf("==========================================================================================================\n");

    while (fread(&add, sizeof(add), 1, playPtr) != 0) {
        // Convert from string to uppercase
        for (int i = 0; add.from[i] != '\0'; ++i) {
            add.from[i] = toupper(add.from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; add.to[i] != '\0'; ++i) {
            add.to[i] = toupper(add.to[i]);
        }
        for (int i = 0; add.startMonth[i] != '\0'; ++i) {
            add.startMonth[i] = toupper(add.startMonth[i]);
        }
        for (int i = 0; add.endMonth[i] != '\0'; ++i) {
            add.endMonth[i] = toupper(add.endMonth[i]);
        }
        printf("|| %-2d  ||%-15s||%-15s|| %02d-%-3s-%-4d     || %02d-%-3s-%-4d    || %02d:%02d      || %02d:%02d    ||\n", add.no,
            add.from, add.to, add.startDay, add.startMonth, add.startYear,
            add.endDay, add.endMonth, add.endYear,
            add.startHour, add.startMinute, add.endHour, add.endMinute);
        count++;
    }

    printf("==========================================================================================================\n");
    printf("\n %d records listed !! \n\n", count);

    fclose(playPtr);
}

// for staff
void modifySchedule() {
    FILE* modiPtr;
    Schedule modi[100];

    int i = 0, count = 0, no, modiCount = 0;
    char from[20], to[20], startMonth[4], endMonth[4], cont;
    int startHour, startMinute, endHour, endMinute, startDay, startYear, endDay, endYear;

    modiPtr = fopen("schedule.txt", "rb");

    if (modiPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }

    while (fread(&modi[i], sizeof(modi[i]), 1, modiPtr) != 0)
    {
        // Convert strings to uppercase
        for (int j = 0; modi[i].from[j] != '\0'; ++j) {
            modi[i].from[j] = toupper(modi[i].from[j]);
        }
        for (int j = 0; modi[i].to[j] != '\0'; ++j) {
            modi[i].to[j] = toupper(modi[i].to[j]);
        }
        for (int j = 0; modi[i].startMonth[j] != '\0'; ++j) {
            modi[i].startMonth[j] = toupper(modi[i].startMonth[j]);
        }
        for (int j = 0; modi[i].endMonth[j] != '\0'; ++j) {
            modi[i].endMonth[j] = toupper(modi[i].endMonth[j]);
        }
        i++; // Increase array index
        count++;  // Count how many records have been read
    }

    fclose(modiPtr);

    do {
        printf("\nEnter No. do you want to Modify > ");
        scanf("%d", &no);

        int foundIndex = -1; // Index of the found record
        for (i = 0; i < count; i++) {
            if (no == modi[i].no) {
                foundIndex = i; // Store the index of the found record
                break;
            }
        }

        if (foundIndex != -1) {
            printf("==========================================================================================================\n");
            printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
            printf("==========================================================================================================\n");
            printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", modi[foundIndex].no,
                modi[foundIndex].from, modi[foundIndex].to, modi[foundIndex].startDay, modi[foundIndex].startMonth, modi[foundIndex].startYear,
                modi[foundIndex].endDay, modi[foundIndex].endMonth, modi[foundIndex].endYear,
                modi[foundIndex].startHour, modi[foundIndex].startMinute, modi[foundIndex].endHour, modi[foundIndex].endMinute);
            printf("==========================================================================================================\n");

            printf("\nUpdate New Details > \n");
            printf("From WHERE\t\t\t> ");
            rewind(stdin);
            scanf(" %[^\n]", from);
            printf("To WHERE\t\t\t> ");
            rewind(stdin);
            scanf(" %[^\n]", to);
            printf("Date of Journey (DD/MMM/YYYY)\t> ");
            rewind(stdin);
            scanf("%d/%[^/]/%d", &startDay, startMonth, &startYear);
            printf("Date of Return (DD/MMM/YYYY)\t> ");
            rewind(stdin);
            scanf("%d/%[^/]/%d", &endDay, endMonth, &endYear);
            printf("Time of Journey (HH:MM)\t\t> ");
            rewind(stdin);
            scanf("%d:%d", &startHour, &startMinute);
            printf("Return of Journey (HH:MM)\t> ");
            rewind(stdin);
            scanf("%d:%d", &endHour, &endMinute);

            strcpy(modi[foundIndex].from, from);
            strcpy(modi[foundIndex].to, to);
            modi[foundIndex].startDay = startDay;
            strcpy(modi[foundIndex].startMonth, startMonth);
            modi[foundIndex].startYear = startYear;
            modi[foundIndex].endDay = endDay;
            strcpy(modi[foundIndex].endMonth, endMonth);
            modi[foundIndex].endYear = endYear;
            modi[foundIndex].startHour = startHour;
            modi[foundIndex].startMinute = startMinute;
            modi[foundIndex].endHour = endHour;
            modi[foundIndex].endMinute = endMinute;

            printf("\nConfirm to modify (Y = yes | N = no) ?  > ");
            scanf(" %c", &ans);

            if (toupper(ans) == 'Y') {
                modiCount++;
                printf("\nUpdated record:\n");
                printf("==========================================================================================================\n");
                printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
                printf("==========================================================================================================\n");
                printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", modi[foundIndex].no,
                    modi[foundIndex].from, modi[foundIndex].to, modi[foundIndex].startDay, modi[foundIndex].startMonth, modi[foundIndex].startYear,
                    modi[foundIndex].endDay, modi[foundIndex].endMonth, modi[foundIndex].endYear,
                    modi[foundIndex].startHour, modi[foundIndex].startMinute, modi[foundIndex].endHour, modi[foundIndex].endMinute);
                printf("==========================================================================================================\n");
            }
            else {
                printf("\n No Changes Made !!! \n");
            }
        }
        else {
            printf("\nRecord with No. %d not found.\n", no);
        }

        printf("\nAny more record to modify (Y = yes | N = no) ? >  ");
        scanf(" %c", &cont);

    } while (toupper(cont) == 'Y'); // Loop while cont = Y/y

    // Write array of records to file
    modiPtr = fopen("schedule.txt", "wb");
    if (modiPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }
    // Use for loop to copy record by record into binary file
    for (i = 0; i < count; i++) {
        fwrite(&modi[i], sizeof(modi[i]), 1, modiPtr);
    }
    fclose(modiPtr);

    printf("\n\t%d Record(s) modified.\n\n", modiCount);
}

// for member
void searchSchedule() { 
    FILE* srcPtr;
    Schedule src[100];
    srcPtr = fopen("schedule.txt", "rb");

    char from[20], to[20], cont;
    int count = 0;


    if (srcPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }

    while (fread(&src[count], sizeof(src[count]), 1, srcPtr) == 1) {
        for (int i = 0; src[count].from[i] != '\0'; ++i) {
            src[count].from[i] = toupper(src[count].from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; src[count].to[i] != '\0'; ++i) {
            src[count].to[i] = toupper(src[count].to[i]);
        }
        for (int i = 0; src[count].startMonth[i] != '\0'; ++i) {
            src[count].startMonth[i] = toupper(src[count].startMonth[i]);
        }
        for (int i = 0; src[count].endMonth[i] != '\0'; ++i) {
            src[count].endMonth[i] = toupper(src[count].endMonth[i]);
        }
        count++;
    }

    fclose(srcPtr);

    do {
        printf("From WHERE\t\t\t> ");
        rewind(stdin);
        scanf("%[^\n]", from);
        printf("To WHERE\t\t\t> ");
        rewind(stdin);
        scanf("%[^\n]", to);

        for (int i = 0; from[i] != '\0'; ++i) {
            from[i] = toupper(from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; to[i] != '\0'; ++i) {
            to[i] = toupper(to[i]);
        }

        printf("==========================================================================================================\n");
        printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
        printf("==========================================================================================================\n");
        int found = 0;
        for (int i = 0; i < count; i++) {
            if (strcmp(from, src[i].from) == 0 && strcmp(to, src[i].to) == 0 ) {
                found = 1;
                
                printf("|| %-2d  ||%-15s||%-15s|| %02d-%-3s-%-4d     || %02d-%-3s-%-4d    || %02d:%02d      || %02d:%02d    ||\n", src[i].no,
                    src[i].from, src[i].to, src[i].startDay, src[i].startMonth, src[i].startYear, src[i].endDay, src[i].endMonth, src[i].endYear,
                    src[i].startHour, src[i].startMinute, src[i].endHour, src[i].endMinute);
                
            }
        }
        printf("==========================================================================================================\n");

        if (!found) {
            printf("\nSorry, no tickets available for your selected trip.\n");
        }

 
        printf("\nAny more records to search (Y = yes | N = no) ? > ");
        rewind(stdin);
        scanf(" %c", &cont);

    } while (toupper(cont) == 'Y');

 
}

// for staff
void deleteSchedule() {
    FILE* delPtr;
    Schedule del[100];
    int count = 0, i = 0, found = 0, no, current;

    delPtr = fopen("schedule.txt", "rb");

    if (delPtr == NULL) {
        printf("ERROR - File does not exist !\n\n");
        exit(-1);
    }

    // Read records from file
    while (fread(&del[count], sizeof(del[count]), 1, delPtr) != 0) {
        for (i = 0; del[count].from[i] != '\0'; ++i) {
            del[count].from[i] = toupper(del[count].from[i]);
        }
        // Convert to string to uppercase
        for (i = 0; del[count].to[i] != '\0'; ++i) {
            del[count].to[i] = toupper(del[count].to[i]);
        }
        for (i = 0; del[count].startMonth[i] != '\0'; ++i) {
            del[count].startMonth[i] = toupper(del[count].startMonth[i]);
        }
        for (i = 0; del[count].endMonth[i] != '\0'; ++i) {
            del[count].endMonth[i] = toupper(del[count].endMonth[i]);
        }
        count++;
        i++;
    }
    fclose(delPtr);

    displaySchedule();
    
    // Ask user for the record number to delete
    printf("\nEnter the number of record you want to delete: ");
    scanf("%d", &no);
    rewind(stdin);

    // Check if the record to delete exists
    for (i = 0; i < count; i++) {
        if (del[i].no == no) {
            found = 1;
            break; // Stop searching if found
        }
    }

    if (found) {
        printf("\n********** Record Found ********* \n");
        printf("==========================================================================================================\n");
        printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
        printf("==========================================================================================================\n");

        // Display the found record
        printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", del[i].no,
            del[i].from, del[i].to, del[i].startDay, del[i].startMonth, del[i].startYear, del[i].endDay, del[i].endMonth, del[i].endYear,
            del[i].startHour, del[i].startMinute, del[i].endHour, del[i].endMinute);
        printf("==========================================================================================================\n");

        printf("\nConfirm to DELETE (Y = yes | N = no)? > ");
        scanf(" %c", &ans);


        // If user confirms deletion
        if (toupper(ans) == 'Y') {
            // Shift the array elements to delete the record
            for (current = i; current < count - 1; current++) {
                del[current] = del[current + 1];
            }
            count--;

            // Renumber the records
            for (i = 0; i < count; i++) {
                del[i].no = i + 1;
            }

            // Open file for writing
            delPtr = fopen("schedule.txt", "wb");

            // Write updated records to file
            for (i = 0; i < count; i++) {
                fwrite(&del[i], sizeof(del[i]), 1, delPtr);
            }
            fclose(delPtr);

            printf("\n **** Record Deleted ****\n\n");
        }
        else {
            printf("\n No Changes Made !!! \n");
        }
    }
    else {
        printf("\nNo Record of this Schedule !\n");
    }
    
}

// for member
void printTicket(char* input_memberid[50]) {
    
    Ticket trainticket;

    FILE* ptr;
    ptr = fopen("booking.dat", "rb");
    if (ptr == NULL) {
        printf("Unable to open booking.dat file, please check again");
        exit(-1);
    }

    printf("\n                                                              < --------------- Train Ticket booked --------------- >                                                   \n");
    printf("                                                        < --------------- Enlarge Program For Better View --------------- >                                               \n");
    printf("===================================================================================================================================================================================\n");
    printf("|| No. || Train ID || Coach No. ||       Seats Selected       ||       From      ||       To        || Departure Date || Departure Time || Arrival Date ||  ETA  || Total  Price ||\n");
    printf("===================================================================================================================================================================================\n");
    
    int no = 0, found = 0;
    while (fread(&trainticket, sizeof(trainticket), 1, ptr) != 0) {
        if (strcmp(input_memberid, trainticket.memberId) == 0) {
            found++;
            printf("||  %2d ||   %-5s  ||  Coach %c  || %26s\b  || %-15s || %-15s ||  %02d-%-3s-%-4d   ||      %02d:%02d     || %02d-%-3s-%-4d  || %02d:%02d ||  RM  %6.2lf  ||\n",
                no + 1, trainticket.trainid, trainticket.coach, trainticket.seats, trainticket.departfrom, trainticket.arriveat, trainticket.startday, trainticket.startmonth,
                trainticket.startyear, trainticket.trainleaveHour, trainticket.trainleaveMinute, trainticket.endday, trainticket.endmonth, trainticket.endyear, trainticket.etaHour, trainticket.etaMinute, trainticket.paid);
            no++;
        }
    }
    if (found < 1) {
    printf("||                                                            <------  You haven't booked any train tickets.  ------>                                                            ||\n");
    }
    printf("===================================================================================================================================================================================\n");
    printf("                                                        *  Please be noted that time displayed are in 24 Hour Format.  *                                                 \n");
    printf("                                                  *  Please be punctual and reach the train station before the train leave.  *                                           \n");
    printf("                                             *  Please be advised that we cannot assume responsibility for any delays incurred!  *                                       \n\n");

    do {
        printf("1) Cancel Booking\n");
        printf("2) Back\n");
        printf("Where do you want to go? > ");
        rewind(stdin);
        scanf("%d", &option);

        switch (option) {
        case 1:
            cancelBooking(no, input_memberid);
            break;
        case 2:
            homeMember(input_memberid);
            break;
        default:
            printf("\n========================================Invalid Input=====================================================\n\n");
        }
    } while (option != 2);

}

// for member
void cancelBooking(int num, char* input_memberid[50]) {
    
    Ticket tick[100];
    int choice, count = 0, found = 0, i;

    FILE* ptr;
    ptr = fopen("booking.dat", "rb");
    if (ptr == NULL) {
        printf("Unable to open booking.dat. Please try again.");
        exit(-1);
    }

    while (fread(&tick[count], sizeof(tick[count]), 1, ptr) != 0) {
        if (strcmp(input_memberid, tick[count].memberId) == 0) {
            count++;
        }
    }

    fclose(ptr);

    do {
        printf("\nSelect No. of which booking you wanted to cancel > ");
        rewind(stdin);
        scanf("%d", &choice);
        if (choice > count) {
            printf("\n=================\n");
            printf(" Invalid Choice. \n");
            printf("=================\n\n");
            return;
        }
        else {
            break;
        }
    
    } while (choice > count);

    printf("\n                                                        < --------------- Train Ticket booked --------------- >                                                           \n");
    printf("                                                   < --------------- Enlarge Program For Better View --------------- >                                                      \n");
    printf("============================================================================================================================================================================\n");
    printf("|| Train ID || Coach No. ||       Seats Selected       ||       From      ||       To        || Departure Date || Departure Time || Arrival Date ||  ETA  || Total  Price ||\n");
    printf("============================================================================================================================================================================\n");

    for (i = 0; i <= num - 1; i++) {
        if (i+1 == choice) {
            printf("||   %-5s  ||  Coach %c  || %26s\b  || %-15s || %-15s ||  %02d-%-3s-%-4d   ||      %02d:%02d     || %02d-%-3s-%-4d  || %02d:%02d ||  RM  %6.2lf  ||\n",
                tick[i].trainid, tick[i].coach, tick[i].seats, tick[i].departfrom, tick[i].arriveat, tick[i].startday, tick[i].startmonth,
                tick[i].startyear, tick[i].trainleaveHour, tick[i].trainleaveMinute, tick[i].endday, tick[i].endmonth, tick[i].endyear, tick[i].etaHour, tick[i].etaMinute, tick[i].paid);
            found = 1;
        }
    }
    
    if (found < 1) {
        printf("||                                                     <---- No. of booking not found. Please check again. ---->                                                          ||\n");
    }

    printf("============================================================================================================================================================================\n");
    printf("                                                 *  Please be noted that time displayed are in 24 Hour Format.  *                                                 \n");
    printf("                                           *  Please be punctual and reach the train station before the train leave.  *                                           \n");
    printf("                                      *  Please be advised that we cannot assume responsibility for any delays incurred!  *                                       \n\n");

    printf("Are you sure you wanted to delete current booking? ( Y = yes | N = no ) > ");
    rewind(stdin);;
    scanf("%c", &ans);

    if (toupper(ans) == 'N') {
        printf("\n==============================\n");
        printf(" Booking cancellation failed.\n");
        printf("==============================\n\n");
    }
    else if (toupper(ans) == 'Y') {

        FILE* fp;
        int current;

        //reduce one record
        num--;
        //use for loop to shift the array element from next position [current+1] to current position
        for (current = choice-1; current <= num; current++) {
            if (current != num) {
                strcpy(tick[current].memberId, tick[current + 1].memberId);
                strcpy(tick[current].trainid, tick[current + 1].trainid);
                strcpy(tick[current].departfrom, tick[current + 1].departfrom);
                strcpy(tick[current].arriveat, tick[current + 1].arriveat);
                tick[current].startday = tick[current + 1].startday;
                strcpy(tick[current].startmonth, tick[current + 1].startmonth);
                tick[current].startyear = tick[current + 1].startyear;
                tick[current].trainleaveHour = tick[current + 1].trainleaveHour;
                tick[current].trainleaveMinute = tick[current + 1].trainleaveMinute;
                tick[current].endday = tick[current + 1].endday;
                strcpy(tick[current].endmonth, tick[current + 1].endmonth);
                tick[current].endyear = tick[current + 1].endyear;
                tick[current].etaHour = tick[current + 1].etaHour;
                tick[current].etaMinute = tick[current + 1].etaMinute;
                tick[current].coach = tick[current + 1].coach;
                strcpy(tick[current].seats, tick[current + 1].seats);
                strcpy(tick[current].method, tick[current + 1].method);
                tick[current].paid = tick[current + 1].paid;
            }
            else
                break;
        }

        //open file pointer for writing
        fp = fopen("booking.dat", "wb");

        //use for loop to write record by record into binary file
        for (i = 0; i < num; i++) {
            fwrite(&tick[i], sizeof(tick[i]), 1, fp);
        }

        fclose(fp);

        printf("\n - - - - - - - - - - - - - - - - - - - - - \n");
        printf("| Processing Cancellation and Refund...   | \n");
        printf(" - - - - - - - - - - - - - - - - - - - - -  \n\n");
        system("pause");

        printf("\n=================================================================\n");
        printf(" Booking cancelled. Refund will be issued within 3 business day.\n");
        printf("=================================================================\n\n");
        num -= 1;
    }
}

// home
int main() {
    
    char input_memberid[50];
    int choice;
    
    colouring();
    colour("black");

    do {
        system("cls");
        puts("   ----------------------------------------------------------------------------------------");
        puts("  |  ___                    ___                    ___                   __                |");
        puts("  | |      ___    ___      |      ___    ___      |         |   ___     |  |  |        |   |");
        puts("  | |     |   |  |   |     |     |   |  |   |      ---   ---|  |   |    |---| |--   ---|   |");
        puts("  | |___   ---    ---      |___   ---    ---       ___| |___|  |   |    |___| |  | |___|   |");
        puts("  |                                                                                        |");
        puts("   ----------------------------------------------------------------------------------------");
        puts("");
    
        puts("1) Member");
        puts("2) Staff");
        puts("3) Exit Program");
        printf("\nMember or Staff? > ");
        rewind(stdin);
        scanf("%d", &option);
        switch (option) {
        case 1:
            printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
            printf("\t\t\t\t\t\tWelcome To Our Coo Coo Sdn Bhd\n");
            printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n");
            printf("\t\t\t\t\t      Are you a member? (1. Yes / 2. No)    \n");
            printf("\t\t\t\t\t  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n\n");

            printf("Please enter your choice: ");
            scanf("%d", &choice);

            if (choice == 1) {
                loginMember(input_memberid);
                if (strlen(input_memberid) == 0) {
                    printf("Login Failed. Username or Password may be incorrect, please try again later.\n");
                    break;
                }
            }
            else if (choice == 2) {
                registration();
                printf("Your Registration Are Successful! Please Login To Continue..\n");
                loginMember(input_memberid);
                if (strlen(input_memberid) == 0) {
                    printf("Login Failed. Username or Password may be incorrect, please try again later.\n");
                    break;
                }
            }
            else {
                printf("\n<---- Invalid Choice. Exiting... ----> \n\n");
                system("pause");
                system("cls");
                break;
            }
            homeMember(input_memberid);
            break;
        case 2:
            homeStaff();
            break;
        case 3:
            printf("\n======================== THANKS FOR USING COO COO SDN BHD TRAIN TICKETING SYSTEM ========================\n");
            exit(-1);
        default:
            printf("\n========================================Invalid Input=====================================================\n\n");
            system("pause");
            system("cls");
        }
    } while (option != 3);

    return 0;
}


void colour(char colour[70]) {
    
    if ((strcmp(colour, "red") == 0))
        printf("\033[1;31m");
    else if ((strcmp(colour, "yellow") == 0))
        printf("\033[1;33m");
    else if ((strcmp(colour, "black") == 0))
        printf("\033[0;30m");
    else if ((strcmp(colour, "green") == 0))
        printf("\033[0;32m");
    else if ((strcmp(colour, "blue") == 0))
        printf("\033[0;34m");
    else if ((strcmp(colour, "purple") == 0))
        printf("\033[0;35m");
    else if ((strcmp(colour, "cyan") == 0))
        printf("\033[0;36m");
    else if ((strcmp(colour, "white") == 0))
        printf("\033[0;37m");
    else
        printf("\033[0;37m"); //default white
}

void colouring() {
    colour("red");
    printf("ww    www    ww      EEEEEEEEEEEEEE        LLLL                CCCCCCCCCCCCCCCCC         OOOOOOOOOOO          MMMMMM         MMMMMM     EEEEEEEEEEEEEE   \n"); _sleep(SHORT);
    colour("red");
    printf("ww    www    ww      EEEEEEEEEEEEEE        LLLL                CCCCCCCCCCCCCCCCC       OOOO       OOOO        MMMMMMMM     MMMMMMMM     EEEEEEEEEEEEEE \n"); _sleep(SHORT);
    colour("yellow");
    printf("ww    www    ww      EEEE                  LLLL                CCCCC                  OOOO         OOOO       MMM    MMM   MMM  MMM     EEEE     \n"); _sleep(SHORT);
    colour("yellow");
    printf("ww    www    ww      EEEE                  LLLL                CCCCC                 OOOO           OOOO      MMM     MMMMM     MMM     EEEE   \n"); _sleep(SHORT);
    colour("yellow");
    printf("ww   ww ww   ww      EEEEEEEEEEEEEE        LLLL                CCCCC                 OOOO           OOOO      MMM      MMM      MMM     EEEEEEEEEEEEEE   \n"); _sleep(SHORT);
    colour("green");
    printf("ww   ww ww   ww      EEEEEEEEEEEEEE        LLLL                CCCCC                 OOOO           OOOO      MMM      MMM      MMM     EEEEEEEEEEEEEE   \n"); _sleep(SHORT);
    colour("green");
    printf("ww  ww  ww   ww      EEEE                  LLLL                CCCCC                  OOOO          OOOO      MMM      MMM      MMM     EEEE   \n"); _sleep(SHORT);
    colour("green");
    printf("ww ww   ww   ww      EEEE                  LLLL                CCCCC                   OOOO        OOOO       MMM      MMM      MMM     EEEE   \n"); _sleep(SHORT);
    colour("blue");
    printf("wwww      wwww       EEEEEEEEEEEEEE        LLLLLLLLLLLLLLLL    CCCCCCCCCCCCCCCCC        OOOO     OOOO         MMM               MMM     EEEEEEEEEEEEEE   \n"); _sleep(SHORT);
    colour("cyan");
    printf("www        www       EEEEEEEEEEEEEE        LLLLLLLLLLLLLLLL    CCCCCCCCCCCCCCCCC          OOOOOOOOO           MMM               MMM     EEEEEEEEEEEEEE   \n"); _sleep(SHORT);
    colour("cyan");
    printf("\n\n\n");
    colour("cyan");
    printf("CCCCCCCCCCCCCCCCCCCC       OOOOOOOOOO                OOOOOOOOO           CCCCCCCCCCCCCCCCCCCC        OOOOOOOO                   OOOOOO\n"); _sleep(SHORT);
    colour("purple");
    printf("CCCCCCCCCCCCCCCCCCCC    OOOO       OOOO          OOOO        OOOO        CCCCCCCCCCCCCCCCCCCC     OOOO       OOOO           OOOO       OOOO\n"); _sleep(SHORT);
    colour("purple");
    printf("CCCCC                 OOOO          OOOO       OOOO            OOOO      CCCCC                  OOOO           OOOO        OOOO         OOOO\n"); _sleep(SHORT);
    colour("red");
    printf("CCCCC                OOOO            OOOO     OOOO              OOOO     CCCCC                 OOOO              OOOO     OOOO            OOOO\n"); _sleep(SHORT);
    colour("red");
    printf("CCCCC               OOOO              OOOO    OOOO              OOOO     CCCCC                 OOOO               OOOO    OOOO             OOOO \n"); _sleep(SHORT);
    colour("yellow");
    printf("CCCCC               OOOO              OOOO    OOOO              OOOO     CCCCC                 OOOO               OOOO     OOOO            OOOO \n"); _sleep(SHORT);
    colour("yellow");
    printf("CCCCC                OOOO            OOOO      OOOO            OOOO      CCCCC                  OOOO             OOOO      OOOO           OOOO\n"); _sleep(SHORT);
    colour("yellow");
    printf("CCCCC                 OOOO         OOOO         OOOO          OOOO       CCCCC                   OOOO          OOOO         OOOO         OOOO\n"); _sleep(SHORT);
    colour("green");
    printf("CCCCCCCCCCCCCCCCCCCC    OOOO     OOOO              OOOO     OOOO         CCCCCCCCCCCCCCCCCCCC       OOOO      OOOO           OOOO      OOOO\n"); _sleep(SHORT);
    colour("green");
    printf("CCCCCCCCCCCCCCCCCCCC      OOOOOOOO                   OOOOOOOO            CCCCCCCCCCCCCCCCCCCC          OOOOOOO                   OOOOOO\n"); _sleep(SHORT);
    colour("green");
    printf("\n\n\n");
    colour("blue");
    printf("SSSSSSSSSSSSSSSSS    DDDDDDDDDDDD             NNNN            NNN           BBBBBBBBBBBB          HHHHH        HHHHH     DDDDDDDDDDDD\n"); _sleep(SHORT);
    colour("cyan");
    printf("SSSSSSSSSSSSSSSSS    DDDDDDDDDDDDDDDD         NNNN NNN        NNN           BBBBBBBBBBBBBBB       HHHHH        HHHHH     DDDDDDDDDDDDDDDD\n"); _sleep(SHORT);
    colour("cyan");
    printf("SSSSS                DDDDD        DDDDD       NNNN  NNN       NNN           BBBB        BBBB      HHHHH        HHHHH     DDDDD        DDDDD\n"); _sleep(SHORT);
    colour("cyan");
    printf("SSSSS                DDDDD          DDDDD     NNNN   NNN      NNN           BBBB      BBBB        HHHHH        HHHHH     DDDDD          DDDDD\n"); _sleep(SHORT);
    colour("purple");
    printf("SSSSSSSSSSSSSSSSS    DDDDD           DDDDDD   NNNN     NNN    NNN           BBBBBBBBBBB           HHHHHHHHHHHHHHHHHH     DDDDD           DDDDDD\n"); _sleep(SHORT);
    colour("purple");
    printf("SSSSSSSSSSSSSSSSS    DDDDD           DDDDD    NNNN      NNN   NNN           BBBB      BBBB        HHHHHHHHHHHHHHHHHH     DDDDD           DDDDD\n"); _sleep(SHORT);
    colour("purple");
    printf("            SSSSS    DDDDD          DDDDDD    NNNN       NNN  NNN           BBBB        BBBB      HHHHH        HHHHH     DDDDD          DDDDDD\n"); _sleep(SHORT);
    colour("red");
    printf("            SSSSS    DDDDD         DDDDD      NNNN        NNN NNN           BBBB         BBBBB    HHHHH        HHHHH     DDDDD         DDDDD\n"); _sleep(SHORT);
    colour("red");
    printf("SSSSSSSSSSSSSSSSS    DDDDDDDDDDDDDDDDD        NNNN         NNNNN            BBBBBBBBBBBBBBBB      HHHHH        HHHHH     DDDDDDDDDDDDDDDDD\n"); _sleep(SHORT);
    colour("yellow");
    printf("SSSSSSSSSSSSSSSSS    DDDDDDDDDDDD             NNNN          NNNN            BBBBBBBBBBBB          HHHHH        HHHHH     DDDDDDDDDDDD\n"); _sleep(SHORT);
    colour("yellow");

    _sleep(LONG);
    system("CLS");
}