#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <windows.h>

typedef struct {
    char from[20], to[20], startMonth[4], endMonth[4], confirmation, conti;
    int startHour, startMinute, endHour, endMinute, price, startDay, startYear, endDay, endYear, totalTicket, no;
 
}Schedule;

void displaySchedule();
void addSchedule();
void searchSchedule();
void modifySchedule();
void deleteSchedule();

char ans;
void addSchedule() {
    FILE* addPtr;
    Schedule add;
    int count = 0;

    // Open the file in read mode to count the existing records
    addPtr = fopen("schedule.txt", "rb");
    if (addPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }
    else {
        // Count the existing records
        while (fread(&add, sizeof(add), 1, addPtr) != 0) {
            count++;
        }
        fclose(addPtr);
    }

    // Open the file in append mode to add the new record
    addPtr = fopen("schedule.txt", "ab");
    if (addPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }
    else {
            add.no = count + 1;

            do {
                printf("From\t\t\t\t:");
                rewind(stdin);
                scanf("%[^\n]", add.from);
                printf("To\t\t\t\t:");
                rewind(stdin);
                scanf("%[^\n]", add.to);
                printf("Date of Journey (DD/MMM/YYYY)\t:");
                rewind(stdin);
                scanf("%d/%[^\/]/%d", &add.startDay, add.startMonth, &add.startYear);
                printf("Date of Return (DD/MMM/YYYY)\t:");
                rewind(stdin);
                scanf("%d/%[^\/]/%d", &add.endDay, add.endMonth, &add.endYear);
                printf("Time of Journey (HH:MM)\t\t:");
                rewind(stdin);
                scanf("%d:%d", &add.startHour, &add.startMinute);
                printf("Return of Journey (HH:MM)\t:");
                rewind(stdin);
                scanf("%d:%d", &add.endHour, &add.endMinute);
                rewind(stdin);
                
                fwrite(&add, sizeof(add), 1, addPtr);
                count++;
                printf("\nNew record has been added successfully!");

                printf("\nDo you want to continue add anything ? (Y/N) ");
                scanf("%[^\n]", &add.conti); // Remove & from &add.conti
                rewind(stdin);

                add.no++;

                
            } while (toupper(add.conti) == 'Y'); // Remove & from &add.conti

            
      
    }
    fclose(addPtr);
}



void displaySchedule() {
    FILE* playPtr;
    int count = 0;
    Schedule add;

    playPtr = fopen("schedule.txt", "rb");
    if (playPtr == NULL) {
        printf("ERROR! - Unable to open the Add Schedule File!\n\n");
        exit(-1);
    }

    printf("==========================================================================================================\n");
    printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
    printf("==========================================================================================================\n");

    while (fread(&add, sizeof(add), 1, playPtr) != 0) {
        // Convert from string to uppercase
        for (int i = 0; add.from[i] != '\0'; ++i) {
            add.from[i] = toupper(add.from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; add.to[i] != '\0'; ++i) {
            add.to[i] = toupper(add.to[i]);
        }
        for (int i = 0; add.startMonth[i] != '\0'; ++i) {
            add.startMonth[i] = toupper(add.startMonth[i]);
        }
        for (int i = 0; add.endMonth[i] != '\0'; ++i) {
            add.endMonth[i] = toupper(add.endMonth[i]);
        }
        printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", add.no,
            add.from, add.to, add.startDay, add.startMonth, add.startYear,
            add.endDay, add.endMonth, add.endYear,
            add.startHour, add.startMinute, add.endHour, add.endMinute);
        count++;
    }

    printf("==========================================================================================================\n");
    printf("\n %d records listed !! \n\n", count);

    fclose(playPtr);

    int option;

    do {
        printf("\n1)Display Schedule\n");
        printf("2)Add Schedule\n");
        printf("3)Modify Schedule\n");
        printf("4)Search Schedule\n");
        printf("5)Delete Schedule\n");
        printf("6)Exit Program\n");
        printf("\nPlease Select Any Number :");
        scanf("%d", &option);

        switch (option) {
        case 1:
            displaySchedule();
            break;
        case 2:
            addSchedule();
            break;
        case 3:
            modifySchedule();
            break;
        case 4:
            searchSchedule();
            break;
        case 5:
            deleteSchedule();
            break;
        case 6:
            printf("\n========================================END OF PROGRAM====================================================\n");
            break;
        default:
            printf("\n========================================Invalid Input=====================================================\n");
        }
    } while (option != 6);

    
}


void modifySchedule() {
    FILE* modiPtr;
    Schedule modi[100];

    int i = 0, count = 0, no, modiCount = 0;
    char from[20], to[20], startMonth[4], endMonth[4], ans, cont;
    int startHour, startMinute, endHour, endMinute, startDay, startYear, endDay, endYear;

    modiPtr = fopen("schedule.txt", "rb");

    if (modiPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }

    while (fread(&modi[i], sizeof(modi[i]), 1, modiPtr) != 0)
    {
        // Convert strings to uppercase
        for (int j = 0; modi[i].from[j] != '\0'; ++j) {
            modi[i].from[j] = toupper(modi[i].from[j]);
        }
        for (int j = 0; modi[i].to[j] != '\0'; ++j) {
            modi[i].to[j] = toupper(modi[i].to[j]);
        }
        for (int j = 0; modi[i].startMonth[j] != '\0'; ++j) {
            modi[i].startMonth[j] = toupper(modi[i].startMonth[j]);
        }
        for (int j = 0; modi[i].endMonth[j] != '\0'; ++j) {
            modi[i].endMonth[j] = toupper(modi[i].endMonth[j]);
        }
        i++; // Increase array index
        count++;  // Count how many records have been read
    }

    fclose(modiPtr);

    do {
        printf("\nEnter No. do you want to Modify :");
        scanf("%d", &no);

        int foundIndex = -1; // Index of the found record
        for (i = 0; i < count; i++) {
            if (no == modi[i].no) {
                foundIndex = i; // Store the index of the found record
                break;
            }
        }

        if (foundIndex != -1) {
            printf("==========================================================================================================\n");
            printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
            printf("==========================================================================================================\n");
            printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", modi[foundIndex].no,
                modi[foundIndex].from, modi[foundIndex].to, modi[foundIndex].startDay, modi[foundIndex].startMonth, modi[foundIndex].startYear,
                modi[foundIndex].endDay, modi[foundIndex].endMonth, modi[foundIndex].endYear,
                modi[foundIndex].startHour, modi[foundIndex].startMinute, modi[foundIndex].endHour, modi[foundIndex].endMinute);
            printf("==========================================================================================================\n");

            printf("\nUpdate New Details :\n");
            printf("From\t\t\t\t:");
            rewind(stdin);
            scanf(" %[^\n]", from);
            printf("To\t\t\t\t:");
            rewind(stdin);
            scanf(" %[^\n]", to);
            printf("Date of Journey (DD/MMM/YYYY)\t:");
            rewind(stdin);
            scanf("%d/%[^/]/%d", &startDay, startMonth, &startYear);
            printf("Date of Return (DD/MMM/YYYY)\t:");
            rewind(stdin);
            scanf("%d/%[^/]/%d", &endDay, endMonth, &endYear);
            printf("Time of Journey (HH:MM)\t\t:");
            rewind(stdin);
            scanf("%d:%d", &startHour, &startMinute);
            printf("Return of Journey (HH:MM)\t:");
            rewind(stdin);
            scanf("%d:%d", &endHour, &endMinute);

            strcpy(modi[foundIndex].from, from);
            strcpy(modi[foundIndex].to, to);
            modi[foundIndex].startDay = startDay;
            strcpy(modi[foundIndex].startMonth, startMonth);
            modi[foundIndex].startYear = startYear;
            modi[foundIndex].endDay = endDay;
            strcpy(modi[foundIndex].endMonth, endMonth);
            modi[foundIndex].endYear = endYear;
            modi[foundIndex].startHour = startHour;
            modi[foundIndex].startMinute = startMinute;
            modi[foundIndex].endHour = endHour;
            modi[foundIndex].endMinute = endMinute;

            printf("\nConfirm to modify (Y=yes)? ");
            scanf(" %c", &ans);

            if (toupper(ans) == 'Y') {
                modiCount++;
                printf("\nUpdated record:\n");
                printf("==========================================================================================================\n");
                printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
                printf("==========================================================================================================\n");
                printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", modi[foundIndex].no,
                    modi[foundIndex].from, modi[foundIndex].to, modi[foundIndex].startDay, modi[foundIndex].startMonth, modi[foundIndex].startYear,
                    modi[foundIndex].endDay, modi[foundIndex].endMonth, modi[foundIndex].endYear,
                    modi[foundIndex].startHour, modi[foundIndex].startMinute, modi[foundIndex].endHour, modi[foundIndex].endMinute);
                printf("==========================================================================================================\n");
            }
            else {
                printf("\n No Changes Made !!! \n");
            }
        }
        else {
            printf("\nRecord with No. %d not found.\n", no);
        }

        printf("\nAny more record to modify (Y=yes)? ");
        scanf(" %c", &cont);

    } while (toupper(cont) == 'Y'); // Loop while cont = Y/y

    // Write array of records to file
    modiPtr = fopen("schedule.txt", "wb");
    if (modiPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }
    // Use for loop to copy record by record into binary file
    for (i = 0; i < count; i++) {
        fwrite(&modi[i], sizeof(modi[i]), 1, modiPtr);
    }
    fclose(modiPtr);

    printf("\n\t%d Record(s) modified.\n\n", modiCount);
}



void searchSchedule() {
    FILE* srcPtr;
    Schedule src[100];
    srcPtr = fopen("schedule.txt", "rb");

    char from[20], to[20], startMonth[4], endMonth[4], cont;
    int startHour, startMinute, endHour, endMinute, startDay, startYear, endDay, endYear, count = 0;


    if (srcPtr == NULL) {
        printf("File opening error\n");
        exit(-1);
    }

    while (fread(&src[count], sizeof(src[count]), 1, srcPtr) == 1) {
        for (int i = 0; src[count].from[i] != '\0'; ++i) {
            src[count].from[i] = toupper(src[count].from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; src[count].to[i] != '\0'; ++i) {
            src[count].to[i] = toupper(src[count].to[i]);
        }
        for (int i = 0; src[count].startMonth[i] != '\0'; ++i) {
            src[count].startMonth[i] = toupper(src[count].startMonth[i]);
        }
        for (int i = 0; src[count].endMonth[i] != '\0'; ++i) {
            src[count].endMonth[i] = toupper(src[count].endMonth[i]);
        }
        count++;
    }

    fclose(srcPtr);

    do {
        printf("From\t\t\t\t:");
        rewind(stdin);
        scanf("%[^\n]", from);
        printf("To\t\t\t\t:");
        rewind(stdin);
        scanf("%[^\n]", to);

        for (int i = 0; from[i] != '\0'; ++i) {
            from[i] = toupper(from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; to[i] != '\0'; ++i) {
            to[i] = toupper(to[i]);
        }

        printf("==========================================================================================================\n");
        printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
        printf("==========================================================================================================\n");
        int found = 0;
        for (int i = 0; i < count; i++) {
            if (strcmp(from, src[i].from) == 0 && strcmp(to, src[i].to) == 0 ) {
                found = 1;
                
                printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", src[i].no,
                    src[i].from, src[i].to, src[i].startDay, src[i].startMonth, src[i].startYear, src[i].endDay, src[i].endMonth, src[i].endYear,
                    src[i].startHour, src[i].startMinute, src[i].endHour, src[i].endMinute);
                
            }
        }
        printf("==========================================================================================================\n");

        if (!found) {
            printf("\nSorry, no tickets available for your selected trip.\n");
        }

 
        printf("\nAny more records to search (Y=yes)? ");
        rewind(stdin);
        scanf(" %c", &cont);

    } while (toupper(cont) == 'Y');

 
}


void deleteSchedule() {
    FILE* delPtr;
    Schedule del[100];
    int count = 0, i = 0, found = 0, no, current;

    delPtr = fopen("schedule.txt", "rb");

    if (delPtr == NULL) {
        printf("ERROR - File does not exist !\n\n");
        exit(-1);
    }

    // Read records from file
    while (fread(&del[count], sizeof(del[count]), 1, delPtr) != 0) {
        for (int i = 0; del[count].from[i] != '\0'; ++i) {
            del[count].from[i] = toupper(del[count].from[i]);
        }
        // Convert to string to uppercase
        for (int i = 0; del[count].to[i] != '\0'; ++i) {
            del[count].to[i] = toupper(del[count].to[i]);
        }
        for (int i = 0; del[count].startMonth[i] != '\0'; ++i) {
            del[count].startMonth[i] = toupper(del[count].startMonth[i]);
        }
        for (int i = 0; del[count].endMonth[i] != '\0'; ++i) {
            del[count].endMonth[i] = toupper(del[count].endMonth[i]);
        }
        count++;
        i++;
    }
    fclose(delPtr);

    // Ask user for the record number to delete
    printf("\nEnter the number you want to delete: ");
    scanf("%d", &no);
    rewind(stdin);

    // Check if the record to delete exists
    for (i = 0; i < count; i++) {
        if (del[i].no == no) {
            found = 1;
            break; // Stop searching if found
        }
    }

    if (found) {
        printf("\n********** Record Found ********* \n");
        printf("==========================================================================================================\n");
        printf("|| No. ||     From      ||      To       || Date of Journey || Date of Return || Start Time || End Time ||\n");
        printf("==========================================================================================================\n");

        // Display the found record
        printf("|| %-2d  ||%-15s||%-15s||%02d-%-3s-%-4d      ||%02d-%-3s-%-4d     ||%02d:%02d       ||%02d:%02d     ||\n", del[i].no,
            del[i].from, del[i].to, del[i].startDay, del[i].startMonth, del[i].startYear, del[i].endDay, del[i].endMonth, del[i].endYear,
            del[i].startHour, del[i].startMinute, del[i].endHour, del[i].endMinute);
        printf("==========================================================================================================\n");

        printf("\nConfirm to DELETE (Y=yes)? ");
        scanf(" %c", &ans);


        // If user confirms deletion
        if (toupper(ans) == 'Y') {
            // Shift the array elements to delete the record
            for (current = i; current < count - 1; current++) {
                del[current] = del[current + 1];
            }
            count--;

            // Renumber the records
            for (i = 0; i < count; i++) {
                del[i].no = i + 1;
            }

            // Open file for writing
            delPtr = fopen("schedule.txt", "wb");

            // Write updated records to file
            for (i = 0; i < count; i++) {
                fwrite(&del[i], sizeof(del[i]), 1, delPtr);
            }
            fclose(delPtr);

            printf("\n\n **** Record Deleted ****\n");
        }
        else {
            printf("\n No Changes Made !!! \n");
        }
    }
    else {
        printf("\nNo Record of this Schedule !\n");
    }

    int option;

    do {
        printf("\n1)Display Schedule\n");
        printf("2)Add Schedule\n");
        printf("3)Modify Schedule\n");
        printf("4)Search Schedule\n");
        printf("5)Delete Schedule\n");
        printf("6)Exit Program\n");
        printf("\nPlease Select Any Number :");
        scanf("%d", &option);

        switch (option) {
        case 1:
            displaySchedule();
            break;
        case 2:
            addSchedule();
            break;
        case 3:
            modifySchedule();
            break;
        case 4:
            searchSchedule();
            break;
        case 5:
            deleteSchedule();
            break;
        case 6:
            printf("\n========================================END OF PROGRAM====================================================\n");
            exit(-1);
            break;
        default:
            printf("\n========================================Invalid Input=====================================================\n");
        }
    } while (option != 6);
    
}


int main() {
    displaySchedule();
    return 0;
}
