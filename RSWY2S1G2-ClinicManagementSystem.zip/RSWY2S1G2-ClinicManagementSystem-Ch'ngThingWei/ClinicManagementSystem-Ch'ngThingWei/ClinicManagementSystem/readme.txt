****README****
To run the project:
1.) navigate to src folder
2.) navigate to client folder
3.) run the ClinicManagementSystem.java file

1st page
user can choose 3 option, 1.user which is for patient, 2. admin which is for the clinic admin, and 0. is for exit the menu.

(user menu)
patient or user can access the menu by key in their own patient id then it will prompt a user menu with all 5 modules flow start from patient->consultation->treatment.

(admin menu)
admin can access the menu without any login credential and they can access to all the 5 modules with necessary functions to perform.